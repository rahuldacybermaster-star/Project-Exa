'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  Shield, 
  LifeBuoy, 
  GraduationCap, 
  CheckCircle2, 
  Calendar, 
  Bell, 
  Menu, 
  X, 
  Globe, 
  AlertOctagon, 
  UserCheck, 
  ChevronDown,
  Lock,
  PhoneCall,
  ExternalLink
} from 'lucide-react';
import { CyberShieldLogo } from './CyberShieldLogo';
import { useI18n } from '@/lib/i18n';
import { useApp } from '@/lib/app-context';

export function Navbar() {
  const pathname = usePathname();
  const { lang, setLang, t } = useI18n();
  const { currentUser, switchRole, notifications, markAllNotificationsRead } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [roleSwitcherOpen, setRoleSwitcherOpen] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.isRead);

  const navLinks = [
    { name: t('nav.home'), href: '/' },
    { name: t('nav.help_center'), href: '/help-center' },
    { name: t('nav.incidents'), href: '/incidents' },
    { name: t('nav.academy'), href: '/academy' },
    { name: t('nav.events'), href: '/events' },
    { name: t('nav.verify'), href: '/verify' },
    { name: t('nav.about'), href: '/about' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#050505]/95 backdrop-blur-md border-b border-white/10 select-none">
      {/* Sleek Top Utility Bar */}
      <div className="bg-[#09090b] border-b border-white/5 px-4 py-1 text-[11px] font-mono text-neutral-400">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
          {/* Emergency status ticker */}
          <div className="flex items-center gap-3 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="inline-flex items-center gap-1.5 text-[#ff3e00] font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#ff3e00] animate-pulse"></span>
              24/7 STUDENT CYBER RESPONSE
            </span>
            <span className="hidden md:inline text-neutral-700">|</span>
            <span className="hidden md:inline text-neutral-400">
              POLICE: <strong className="text-white">999</strong> • CYBER DESK: <strong className="text-white">01320000888</strong>
            </span>
          </div>

          {/* Utility actions (Language & Role switch) */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Language toggle pill */}
            <button
              onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-1 px-2 py-0.5 rounded border border-white/10 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition text-[11px]"
              title="Switch Language"
            >
              <Globe className="w-3 h-3 text-[#ff3e00]" />
              <span>{lang === 'en' ? 'বাংলা' : 'EN'}</span>
            </button>

            {/* Simulated role selector */}
            <div className="relative">
              <button
                onClick={() => setRoleSwitcherOpen(!roleSwitcherOpen)}
                className="flex items-center gap-1.5 px-2.5 py-0.5 rounded border border-white/10 bg-neutral-900 hover:border-white/20 text-neutral-300 hover:text-white transition text-[11px]"
              >
                <Lock className="w-2.5 h-2.5 text-[#ff3e00]" />
                <span className="hidden sm:inline text-neutral-400">ROLE:</span>
                <span className="font-semibold text-white" suppressHydrationWarning>{currentUser?.role.replace('_', ' ')}</span>
                <ChevronDown className="w-3 h-3 text-neutral-500" />
              </button>

              {roleSwitcherOpen && (
                <div className="absolute right-0 mt-1.5 w-60 bg-[#0e0e11] border border-white/15 rounded-lg shadow-2xl p-2 z-50 space-y-1">
                  <div className="text-[10px] uppercase font-mono text-neutral-400 px-2 py-1 border-b border-white/5 mb-1">
                    Simulate Perspective:
                  </div>
                  <button
                    onClick={() => { switchRole('SUPER_ADMIN'); setRoleSwitcherOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between font-mono ${currentUser?.role === 'SUPER_ADMIN' ? 'bg-[#ff3e00]/15 text-[#ff3e00] font-bold' : 'text-neutral-300 hover:bg-neutral-800'}`}
                  >
                    <span>Super Admin</span>
                    <span className="text-[10px] bg-red-950/80 text-red-400 border border-red-800/40 px-1.5 py-0.2 rounded">ROOT</span>
                  </button>
                  <button
                    onClick={() => { switchRole('SUPPORT_AGENT'); setRoleSwitcherOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between font-mono ${currentUser?.role === 'SUPPORT_AGENT' ? 'bg-[#ff3e00]/15 text-[#ff3e00] font-bold' : 'text-neutral-300 hover:bg-neutral-800'}`}
                  >
                    <span>Support Responder</span>
                    <span className="text-[10px] bg-blue-950/80 text-blue-400 border border-blue-800/40 px-1.5 py-0.2 rounded">TRIAGE</span>
                  </button>
                  <button
                    onClick={() => { switchRole('VERIFICATION_OFFICER'); setRoleSwitcherOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between font-mono ${currentUser?.role === 'VERIFICATION_OFFICER' ? 'bg-[#ff3e00]/15 text-[#ff3e00] font-bold' : 'text-neutral-300 hover:bg-neutral-800'}`}
                  >
                    <span>Verification Officer</span>
                    <span className="text-[10px] bg-amber-950/80 text-amber-400 border border-amber-800/40 px-1.5 py-0.2 rounded">AUTH</span>
                  </button>
                  <button
                    onClick={() => { switchRole('STUDENT'); setRoleSwitcherOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between font-mono ${currentUser?.role === 'STUDENT' ? 'bg-[#ff3e00]/15 text-[#ff3e00] font-bold' : 'text-neutral-300 hover:bg-neutral-800'}`}
                  >
                    <span>Student / Learner</span>
                    <span className="text-[10px] bg-neutral-800 text-neutral-300 px-1.5 py-0.2 rounded">USER</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <Link href="/" className="hover:opacity-95 transition shrink-0 mr-6 xl:mr-10">
            <CyberShieldLogo size="md" />
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-4 xl:gap-7">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`relative py-1 text-xs font-semibold uppercase tracking-wider transition-colors duration-150 whitespace-nowrap ${
                    isActive 
                      ? 'text-white' 
                      : 'text-neutral-400 hover:text-neutral-100'
                  }`}
                >
                  <span>{link.name}</span>
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#ff3e00]" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Group */}
          <div className="hidden sm:flex items-center gap-3 shrink-0 ml-6 xl:ml-10">
            {/* Notification Bell with Dropdown */}
            <div className="relative">
              <button
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="p-2 rounded-lg border border-white/10 text-neutral-400 hover:text-white hover:bg-neutral-900 transition relative"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifs.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#ff3e00]"></span>
                )}
              </button>

              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#0e0e11] border border-white/15 rounded-lg shadow-2xl p-4 z-50">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-white">Broadcasts</h4>
                    <button 
                      onClick={markAllNotificationsRead}
                      className="text-[11px] text-[#ff3e00] hover:underline font-mono"
                    >
                      Clear all
                    </button>
                  </div>
                  <div className="mt-3 space-y-2 max-h-72 overflow-y-auto pr-1">
                    {notifications.map(notif => (
                      <div 
                        key={notif.id}
                        className={`p-2.5 rounded border text-xs transition ${
                          notif.isRead ? 'bg-black/40 border-white/5 text-neutral-400' : 'bg-neutral-900 border-white/15 text-neutral-200'
                        }`}
                      >
                        <div className="flex items-center justify-between font-medium text-white mb-1">
                          <span>{notif.title}</span>
                          <span className="text-[10px] text-neutral-500 font-mono">
                            {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-neutral-400 leading-relaxed">{notif.message}</p>
                        {notif.linkUrl && (
                          <Link 
                            href={notif.linkUrl}
                            onClick={() => setNotifDropdownOpen(false)}
                            className="inline-block mt-2 text-[#ff3e00] hover:underline font-mono text-[11px]"
                          >
                            Details →
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Desk Button if responder or admin */}
            {currentUser?.role !== 'STUDENT' && (
              <Link
                href="/incidents"
                className="px-3 py-1.5 text-xs font-mono uppercase tracking-wider rounded border border-[#ff3e00]/30 text-[#ff3e00] bg-[#ff3e00]/5 hover:bg-[#ff3e00]/15 transition flex items-center gap-1.5"
              >
                <Shield className="w-3 h-3" />
                <span>Desk</span>
              </Link>
            )}

            {/* Primary Get Help Action Button */}
            <Link
              href="/help-center/submit"
              className="px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg bg-[#ff3e00] hover:bg-[#ff541e] text-white shadow-sm transition flex items-center gap-2"
            >
              <LifeBuoy className="w-3.5 h-3.5" />
              <span>{t('nav.get_help')}</span>
            </Link>
          </div>

          {/* Mobile hamburger menu toggle */}
          <div className="flex lg:hidden items-center gap-2">
            <Link
              href="/help-center/submit"
              className="px-3 py-1 text-xs font-bold rounded bg-[#ff3e00] text-white"
            >
              Get Help
            </Link>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded border border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-900"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#09090b] border-b border-white/10 px-4 pt-3 pb-6 space-y-3">
          <nav className="grid grid-cols-1 gap-1">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-3 py-2 text-xs font-semibold uppercase tracking-wider rounded transition ${
                    isActive 
                      ? 'bg-neutral-800 text-white' 
                      : 'text-neutral-300 hover:bg-neutral-900 hover:text-white'
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>
          
          <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-2 text-center text-xs font-mono">
            <Link
              href="/help-center/track"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded bg-neutral-900 text-neutral-200 border border-white/10"
            >
              Track Ticket
            </Link>
            <Link
              href="/verify"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded bg-neutral-900 text-[#ff3e00] border border-[#ff3e00]/30"
            >
              Verify Member
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

