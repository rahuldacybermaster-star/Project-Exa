import React from 'react';

interface CyberShieldLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export function CyberShieldLogo({ className = '', size = 'md', showText = true }: CyberShieldLogoProps) {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-8 h-8',
    lg: 'w-11 h-11',
  };

  return (
    <div className={`flex items-center gap-3 shrink-0 whitespace-nowrap select-none ${className}`}>
      <div className={`relative ${iconSizes[size]} flex items-center justify-center rounded-lg bg-neutral-900 border border-white/15 text-[#ff3e00] shadow-sm`}>
        <svg 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          className="w-5/6 h-5/6"
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <path d="m9 12 2 2 4-4" stroke="#ffffff" strokeWidth="2.5" />
        </svg>
        <span className="absolute -top-1 -right-1 flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ff3e00] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-[#ff3e00]"></span>
        </span>
      </div>

      {showText && (
        <div className="flex flex-col leading-none">
          <span className="font-mono text-[10px] tracking-[0.2em] text-[#ff3e00] uppercase font-bold">
            CSO • SHIELD
          </span>
          <span className="font-display font-bold text-white tracking-tight text-base sm:text-lg mt-0.5">
            CyberSafe Student Org
          </span>
        </div>
      )}
    </div>
  );
}

