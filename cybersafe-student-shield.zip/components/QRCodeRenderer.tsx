'use client';

import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

interface QRCodeRendererProps {
  value: string;
  size?: number;
  className?: string;
}

export function QRCodeRenderer({ value, size = 180, className = '' }: QRCodeRendererProps) {
  const [dataUrl, setDataUrl] = useState<string>('');

  useEffect(() => {
    if (!value) return;
    QRCode.toDataURL(value, {
      width: size,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then(url => setDataUrl(url))
      .catch(err => console.error('QR generation error', err));
  }, [value, size]);

  if (!dataUrl) {
    return (
      <div 
        style={{ width: size, height: size }} 
        className={`bg-slate-800 animate-pulse rounded-lg flex items-center justify-center text-xs text-slate-400 ${className}`}
      >
        Generating QR...
      </div>
    );
  }

  return (
    <div className={`p-2 bg-white rounded-xl shadow-inner inline-block ${className}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img 
        src={dataUrl} 
        alt={`QR code for ${value}`} 
        width={size} 
        height={size} 
        className="rounded"
      />
    </div>
  );
}
