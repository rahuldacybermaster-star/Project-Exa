import React from 'react';
import { ShieldAlert, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

export function DisclaimerBanner() {
  return (
    <div className="bg-[#0c0c0e] border-b border-white/10 px-4 py-2 text-xs text-neutral-300">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#ff3e00]"></span>
          <span className="font-mono text-[11px] text-[#ff3e00] font-bold uppercase tracking-wider">
            STUDENT INITIATIVE:
          </span>
          <span className="text-neutral-300">
            CSO provides immediate triage and cybersecurity guidance. We are not a law enforcement agency.
          </span>
        </div>
        <div className="flex items-center gap-4 text-neutral-400 font-mono text-[11px]">
          <span>POLICE: <strong className="text-white">999</strong></span>
          <span className="hidden sm:inline text-neutral-700">|</span>
          <Link href="/legal/disclaimer" className="text-white hover:text-[#ff3e00] underline transition">
            Scope & Legal Notice →
          </Link>
        </div>
      </div>
    </div>
  );
}

export function CredentialWarningCallout() {
  return (
    <div className="rounded-lg border border-[#ff3e00]/40 bg-[#ff3e00]/5 p-4 text-neutral-200">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-[#ff3e00] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h4 className="font-display font-bold text-white tracking-tight uppercase text-xs">
            CRITICAL SECURITY DIRECTIVE: NEVER SHARE CREDENTIALS
          </h4>
          <p className="text-xs text-neutral-300 leading-relaxed">
            CSO volunteers and staff will <strong className="text-white">NEVER</strong> ask for your account password, 2FA authenticator codes, OTPs, recovery keys, or financial credentials.
          </p>
        </div>
      </div>
    </div>
  );
}

