'use client';

import React from 'react';
import Link from 'next/link';
import { CyberShieldLogo } from './CyberShieldLogo';
import { 
  ShieldAlert, 
  PhoneCall, 
  FileText, 
  CheckCircle, 
  GraduationCap, 
  Users, 
  HelpCircle, 
  Mail, 
  ExternalLink,
  Lock
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';

export function Footer() {
  const { t } = useI18n();

  return (
    <footer className="bg-[#050505] border-t border-white/10 text-neutral-400 text-sm">
      {/* Emergency Hotline Bar */}
      <div className="bg-[#0a0a0c] border-b border-white/10 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded bg-neutral-900 border border-white/15 text-[#ff3e00]">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-display font-bold text-white text-sm md:text-base uppercase tracking-tight">
                National Cyber & Emergency Hotlines
              </h4>
              <p className="text-xs text-neutral-400 mt-0.5">
                In cases of imminent physical threat, extortion, or blackmail, contact emergency services immediately.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
            <div className="px-3 py-1.5 rounded bg-neutral-900 border border-white/10 text-neutral-300">
              NATIONAL EMERGENCY: <span className="text-[#ff3e00] font-bold">999</span>
            </div>
            <div className="px-3 py-1.5 rounded bg-neutral-900 border border-white/10 text-neutral-300">
              POLICE CYBER DESK: <span className="text-white font-bold">01320000888</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Col 1: Brand & Purpose */}
          <div className="lg:col-span-2 space-y-4">
            <CyberShieldLogo size="md" />
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed max-w-sm">
              {t('footer.about')}
            </p>
            <div className="flex items-center gap-2 text-xs font-mono text-neutral-300">
              <Lock className="w-3.5 h-3.5 text-[#ff3e00]" />
              <span>TLS 1.3 • Zero Credential Storage Policy</span>
            </div>
          </div>

          {/* Col 2: Cyber Help & Incident */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold">
              Help & Incident Triage
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/help-center" className="hover:text-white transition flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-[#ff3e00]" />
                  <span>Cyber Help Center</span>
                </Link>
              </li>
              <li>
                <Link href="/help-center/submit" className="hover:text-[#ff3e00] transition">
                  Submit Help Request
                </Link>
              </li>
              <li>
                <Link href="/help-center/track" className="hover:text-[#ff3e00] transition">
                  Track Existing Ticket
                </Link>
              </li>
              <li>
                <Link href="/incidents" className="hover:text-[#ff3e00] transition">
                  Incident Reporting Portal
                </Link>
              </li>
              <li>
                <Link href="/chat" className="hover:text-[#ff3e00] transition">
                  Live Support Chat
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Academy & Verification */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold">
              Academy & Verification
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/academy" className="hover:text-white transition flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-[#ff3e00]" />
                  <span>Cyber Academy Courses</span>
                </Link>
              </li>
              <li>
                <Link href="/academy/quiz" className="hover:text-[#ff3e00] transition">
                  Cyber Safety Score Quiz
                </Link>
              </li>
              <li>
                <Link href="/verify" className="hover:text-white transition flex items-center gap-1.5 text-white font-semibold">
                  <CheckCircle className="w-3.5 h-3.5 text-[#ff3e00]" />
                  <span>Verify Official Member</span>
                </Link>
              </li>
              <li>
                <Link href="/verify" className="hover:text-[#ff3e00] transition">
                  Verify Certificate ID
                </Link>
              </li>
              <li>
                <Link href="/academy" className="hover:text-[#ff3e00] transition">
                  CTFs & Competitions
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Community & Governance */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold">
              Organization
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/about" className="hover:text-[#ff3e00] transition">
                  About CSO
                </Link>
              </li>
              <li>
                <Link href="/team" className="hover:text-[#ff3e00] transition">
                  Leadership & Mentors
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-[#ff3e00] transition">
                  Campus Representative
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-[#ff3e00] transition">
                  Scope & Legal Notice
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="mt-10 p-4 rounded bg-[#0c0c0e] border border-white/10 text-xs text-neutral-400 leading-relaxed">
          <div className="flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-[#ff3e00] shrink-0 mt-0.5" />
            <p>
              <strong className="text-neutral-200">Legal Disclaimer:</strong> CyberSafe Student Organization (CSO) is a student-led educational and cybersecurity guidance initiative. We do not exercise law enforcement powers or provide formal legal counsel. Submitted logs and evidence are preserved under strict privacy controls solely for incident triage and referral guidance.
            </p>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400 font-mono">
          <p>{t('footer.copyright')}</p>
          <div className="flex items-center gap-4">
            <Link href="/about" className="hover:text-white">ABOUT</Link>
            <span>•</span>
            <Link href="/verify" className="hover:text-white">VERIFY</Link>
            <span>•</span>
            <Link href="/help-center" className="hover:text-white">HELP</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

