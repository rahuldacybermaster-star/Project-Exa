'use client';

import React, { createContext, useContext, useSyncExternalStore, useCallback } from 'react';

export type Language = 'en' | 'bn';

interface I18nContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string, defaultText?: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About',
    'nav.help_center': 'Help Center',
    'nav.academy': 'Academy',
    'nav.courses': 'Courses',
    'nav.articles': 'Guides & Articles',
    'nav.quiz': 'Safety Quiz',
    'nav.incidents': 'Incidents',
    'nav.events': 'Events & CTF',
    'nav.community': 'Community',
    'nav.verify': 'Verify',
    'nav.volunteer': 'Join as Volunteer',
    'nav.campus_rep': 'Campus Representative',
    'nav.news': 'Alerts',
    'nav.faq': 'FAQ',
    'nav.contact': 'Contact',
    'nav.login': 'Sign In',
    'nav.register': 'Join Academy',
    'nav.dashboard': 'Student Portal',
    'nav.admin': 'Admin Panel',
    'nav.get_help': 'Get Help',
    'nav.verify_now': 'Verify Credential',

    // Hero
    'hero.badge': 'Cyber Security Student Organization (CSO)',
    'hero.title': 'Protecting, Educating & Empowering Students in Cyberspace',
    'hero.subtitle': 'Initial cybersecurity triage, ethical guidance, cyberbullying defense, hands-on CTF training, and public member verification — built by students, for students.',
    'hero.cta_help': 'Report Incident / Get Help',
    'hero.cta_learn': 'Explore Academy',
    'hero.cta_verify': 'Verify Official Member',
    'hero.disclaimer': 'Notice: We are a student education and assistance body, not a law-enforcement agency. Never share passwords or OTPs.',

    // Stats
    'stats.students': 'Students Trained',
    'stats.cases': 'Incidents Triaged',
    'stats.members': 'Verified Campus Reps',
    'stats.events': 'Workshops & CTFs',
    'stats.response_time': 'Avg Response Time',

    // Help Center
    'help.title': 'Cyber Help & Triage Center',
    'help.subtitle': 'Encountered account takeover, phishing, blackmail, or malware? Our student response team is here to guide you step-by-step.',
    'help.submit_btn': 'Submit Confidential Request',
    'help.track_btn': 'Track Ticket Status',
    'help.live_chat': 'Open Live Support Chat',
    'help.credential_warning': 'CRITICAL: Never share passwords, OTP codes, banking PINs, or 2FA recovery keys with anyone, including our staff.',

    // Verification
    'verify.title': 'Public Credential Verification',
    'verify.subtitle': 'Instantly verify official organization members, executive leaders, campus representatives, and digital training certificates.',
    'verify.member_tab': 'Verify Member ID',
    'verify.cert_tab': 'Verify Certificate',
    'verify.search_placeholder_member': 'Enter Member ID (e.g. CSO-BD-000124)',
    'verify.search_placeholder_cert': 'Enter Certificate ID (e.g. CSO-CERT-2026-8941)',
    'verify.button': 'Verify Record',

    // Academy
    'academy.title': 'Student Cyber Security Academy',
    'academy.subtitle': 'Master defensive hygiene, ethical hacking foundations, phishing detection, and digital privacy with interactive simulations.',

    // Footer
    'footer.about': 'A dedicated student cybersecurity organization fostering digital resilience, ethical hacking, cyberbullying protection, and threat intelligence across schools and universities.',
    'footer.emergency_title': 'National Emergency Helplines',
    'footer.emergency_cyber': 'Cyber Crime Unit: 01320000888 / 999',
    'footer.emergency_disclaimer': 'Disclaimer: CSO provides educational guidance and technical assistance. In active physical danger or severe financial fraud, contact law enforcement immediately.',
    'footer.copyright': '© 2026 CyberSafe Student Organization (CSO). Non-profit student initiative. All rights reserved.',
  },
  bn: {
    // Navigation
    'nav.home': 'হোম',
    'nav.about': 'সম্পর্কে',
    'nav.help_center': 'হেল্প সেন্টার',
    'nav.academy': 'একাডেমি',
    'nav.courses': 'কোর্সসমূহ',
    'nav.articles': 'গাইড ও আর্টিকেল',
    'nav.quiz': 'সেফটি কুইজ',
    'nav.incidents': 'ইনসিডেন্ট',
    'nav.events': 'ইভেন্ট ও সিটিএফ',
    'nav.community': 'কমিউনিটি',
    'nav.verify': 'ভেরিফাই',
    'nav.volunteer': 'ভলান্টিয়ার আবেদন',
    'nav.campus_rep': 'ক্যাম্পাস প্রতিনিধি',
    'nav.news': 'নিরাপত্তা অ্যালার্ট',
    'nav.faq': 'FAQ',
    'nav.contact': 'যোগাযোগ',
    'nav.login': 'লগইন',
    'nav.register': 'যুক্ত হোন',
    'nav.dashboard': 'স্টুডেন্ট পোর্টাল',
    'nav.admin': 'এডমিন প্যানেল',
    'nav.get_help': 'সহায়তা নিন',
    'nav.verify_now': 'ভেরিফাই করুন',

    // Hero
    'hero.badge': 'স্টুডেন্ট সাইবার সিকিউরিটি অর্গানাইজেশন (CSO)',
    'hero.title': 'সাইবার দুনিয়ায় শিক্ষার্থীদের সুরক্ষা, সচেতনতা ও কারিগরি সহায়তা',
    'hero.subtitle': 'অ্যাকাউন্ট হ্যাকিং, ব্ল্যাকমেইল, ফিশিং প্রতিরোধ, প্র্যাকটিক্যাল সিটিএফ প্রশিক্ষণ ও অফিশিয়াল মেম্বার ভেরিফিকেশন — শিক্ষার্থীদের পাশে সবসময়।',
    'hero.cta_help': 'সহায়তা চান / রিপোর্ট করুন',
    'hero.cta_learn': 'একাডেমি দেখুন',
    'hero.cta_verify': 'অফিশিয়াল সদস্য যাচাই',
    'hero.disclaimer': 'সতর্কবার্তা: আমরা শিক্ষার্থী পরিচালিত সচেতনতামূলক ও প্রাথমিক সহায়তা সংস্থা, কোনো আইন প্রয়োগকারী বাহিনী নই। কখনোই পাসওয়ার্ড বা ওটিপি দেবেন না।',

    // Stats
    'stats.students': 'প্রশিক্ষিত শিক্ষার্থী',
    'stats.cases': 'সহায়তাকৃত ঘটনা',
    'stats.members': 'ভেরিফায়েড ক্যাম্পাস প্রতিনিধি',
    'stats.events': 'ওয়ার্কশপ ও সিটিএফ',
    'stats.response_time': 'গড় রেসপন্স সময়',

    // Help Center
    'help.title': 'সাইবার হেল্প ও ট্রায়াজ সেন্টার',
    'help.subtitle': 'অ্যাকাউন্ট হ্যাক, ফিশিং, অনলাইন হয়রানি বা সাইবার বুলিংয়ের শিকার? আমাদের টিম আপনাকে ধাপে ধাপে দিকনির্দেশনা দেবে।',
    'help.submit_btn': 'সহায়তার আবেদন পাঠান',
    'help.track_btn': 'টিকেটের বর্তমান অবস্থা দেখুন',
    'help.live_chat': 'লাইভ চ্যাট সহায়তা',
    'help.credential_warning': 'জরুরি সতর্কতা: কখনোই আপনার পাসওয়ার্ড, ওটিপি (OTP), ব্যাংক পিন বা ২FA রিকভারি কোড কাউকে দেবেন না—এমনকি আমাদের টিমের সদস্যদেরও না।',

    // Verification
    'verify.title': 'পাবলিক মেম্বার ও সার্টিফিকেট ভেরিফিকেশন',
    'verify.subtitle': 'আমাদের সংস্থার যেকোনো মেম্বার, ক্যাম্পাস প্রতিনিধি বা ট্রেনিং সার্টিফিকেটের সত্যতা সরাসরি এক ক্লিকে যাচাই করুন।',
    'verify.member_tab': 'মেম্বার আইডি যাচাই',
    'verify.cert_tab': 'সার্টিফিকেট যাচাই',
    'verify.search_placeholder_member': 'মেম্বার আইডি দিন (যেমন: CSO-BD-000124)',
    'verify.search_placeholder_cert': 'সার্টিফিকেট আইডি দিন (যেমন: CSO-CERT-2026-8941)',
    'verify.button': 'যাচাই করুন',

    // Academy
    'academy.title': 'স্টুডেন্ট সাইবার সিকিউরিটি একাডেমি',
    'academy.subtitle': 'পাসওয়ার্ড সিকিউরিটি, ২FA, সোশ্যাল মিডিয়া সুরক্ষা ও এথিক্যাল হ্যাকিংয়ের খুঁটিনাটি সহজে শিখুন।',

    // Footer
    'footer.about': 'শিক্ষার্থীদের মধ্যে সাইবার সচেতনতা, অনলাইন নিরাপত্তা, প্রাথমিক কারিগরি সহায়তা ও ডিজিটাল অধিকার সুরক্ষায় নিবেদিত সংগঠন।',
    'footer.emergency_title': 'জাতীয় জরুরি হেল্পলাইন',
    'footer.emergency_cyber': 'সাইবার ক্রাইম তদন্ত বিভাগ: ০১৩২০০০৮৮৮ / ৯৯৯',
    'footer.emergency_disclaimer': 'সতর্কীকরণ: CSO প্রাথমিক সচেতনতা ও নির্দেশনামূলক পরামর্শ দেয়। আইনি ব্যবস্থা নিতে সরাসরি সাইবার পুলিশ ও থানায় অভিযোগ করুন।',
    'footer.copyright': '© ২০২৬ সাইবারসেফ স্টুডেন্ট অর্গানাইজেশন (CSO)। সর্বস্বত্ব সংরক্ষিত।',
  },
};

const subscribers = new Set<() => void>();
function notify() {
  subscribers.forEach(cb => cb());
}

function subscribe(callback: () => void) {
  subscribers.add(callback);
  return () => {
    subscribers.delete(callback);
  };
}

let cachedLang: Language = 'en';

function getLangSnapshot(): Language {
  if (typeof window === 'undefined') return 'en';
  try {
    const saved = localStorage.getItem('cso_lang') as Language;
    if (saved === 'en' || saved === 'bn') {
      cachedLang = saved;
      return saved;
    }
  } catch {
    // fallback
  }
  return cachedLang;
}

function getLangServerSnapshot(): Language {
  return 'en';
}

const I18nContext = createContext<I18nContextType>({
  lang: 'en',
  setLang: () => {},
  t: (key: string) => key,
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const lang = useSyncExternalStore(subscribe, getLangSnapshot, getLangServerSnapshot);

  const setLang = useCallback((newLang: Language) => {
    cachedLang = newLang;
    try {
      localStorage.setItem('cso_lang', newLang);
    } catch {
      // fallback
    }
    notify();
  }, []);

  const t = useCallback((key: string, defaultText?: string) => {
    return translations[lang]?.[key] || defaultText || key;
  }, [lang]);

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}
