'use client';

import React, { createContext, useContext, useState, useSyncExternalStore, useCallback, useMemo } from 'react';
import { 
  User, 
  HelpTicket, 
  TicketMessage,
  IncidentReport, 
  OrgMember, 
  Certificate, 
  Course, 
  Article, 
  EventItem, 
  EventRegistration, 
  VolunteerApplication, 
  AuditLog, 
  NotificationItem, 
  FAQItem, 
  Partner,
  ChatConversation,
  LiveChatMessage,
  IncidentCategory,
  TicketPriority,
  TicketStatus,
  MemberStatus,
  CertificateStatus
} from './types';
import { 
  INITIAL_MEMBERS, 
  INITIAL_CERTIFICATES, 
  INITIAL_TICKETS, 
  INITIAL_INCIDENT_REPORTS, 
  INITIAL_COURSES, 
  INITIAL_ARTICLES, 
  INITIAL_EVENTS, 
  INITIAL_FAQS, 
  INITIAL_PARTNERS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_NOTIFICATIONS, 
  DEMO_USERS 
} from './store';

interface AppContextType {
  // Current user & Auth
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  switchRole: (role: User['role']) => void;
  
  // Data entities
  members: OrgMember[];
  certificates: Certificate[];
  tickets: HelpTicket[];
  incidents: IncidentReport[];
  courses: Course[];
  articles: Article[];
  events: EventItem[];
  eventRegistrations: EventRegistration[];
  volunteerApplications: VolunteerApplication[];
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  faqs: FAQItem[];
  partners: Partner[];
  chats: ChatConversation[];
  activeChat: ChatConversation | null;
  completedLessonIds: string[];
  safetyScore: number;
  
  // Actions
  submitHelpTicket: (data: {
    studentName: string;
    studentEmail: string;
    studentPhone?: string;
    isAnonymous: boolean;
    category: IncidentCategory;
    title: string;
    description: string;
    platformInvolved: string;
    incidentDate: string;
    severity: TicketPriority;
    evidenceFiles?: { name: string; size: string; type: string }[];
  }) => string;
  
  addTicketMessage: (ticketId: string, message: string, isInternalNote?: boolean) => void;
  updateTicketStatus: (ticketId: string, status: TicketStatus, notes?: string) => void;
  assignTicketAgent: (ticketId: string, agentName: string) => void;
  
  submitIncidentReport: (data: {
    reporterName?: string;
    reporterEmail?: string;
    isAnonymous: boolean;
    category: IncidentCategory;
    targetPlatform: string;
    incidentDate: string;
    impactedUrlOrAccount?: string;
    threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    description: string;
  }) => string;

  updateMemberStatus: (memberId: string, status: MemberStatus, reason?: string) => void;
  addMember: (member: OrgMember) => void;
  updateCertificateStatus: (certId: string, status: CertificateStatus) => void;
  issueCertificate: (cert: Omit<Certificate, 'id' | 'hashSignature'>) => string;
  
  registerForEvent: (eventId: string, name: string, email: string, phone: string, institution: string) => string;
  submitVolunteerApplication: (app: Omit<VolunteerApplication, 'id' | 'status' | 'appliedAt'>) => string;
  updateVolunteerStatus: (id: string, status: VolunteerApplication['status']) => void;
  
  completeLesson: (lessonId: string) => void;
  setSafetyScore: (score: number) => void;
  
  // Live Chat
  sendLiveChatMessage: (conversationId: string, message: string, senderType?: 'student' | 'agent') => void;
  startOrGetChat: (studentName: string, studentEmail?: string, ticketId?: string) => ChatConversation;
  setActiveChat: (chat: ChatConversation | null) => void;
  
  // CMS
  createArticle: (art: Omit<Article, 'id' | 'publishedAt'>) => void;
  updateArticle: (id: string, art: Partial<Article>) => void;
  deleteArticle: (id: string) => void;
  createCourse: (c: Omit<Course, 'id'>) => void;
  updateCourse: (id: string, c: Partial<Course>) => void;
  createEvent: (e: Omit<EventItem, 'id'>) => void;
  updateEvent: (id: string, e: Partial<EventItem>) => void;
  
  // Notifications & Audits
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  addAuditLog: (action: string, resource: string, resourceId: string, details: string) => void;
  
  // Reset store
  resetToDefaults: () => void;
}

const userSubscribers = new Set<() => void>();
function notifyUser() {
  userSubscribers.forEach(cb => cb());
}

function subscribeUser(callback: () => void) {
  userSubscribers.add(callback);
  return () => {
    userSubscribers.delete(callback);
  };
}

let cachedUserStr: string = JSON.stringify(DEMO_USERS[0]);

function getUserSnapshot(): string {
  if (typeof window === 'undefined') return cachedUserStr;
  try {
    const saved = localStorage.getItem('cso_current_user');
    if (saved) {
      cachedUserStr = saved;
      return saved;
    }
  } catch {
    // fallback
  }
  return cachedUserStr;
}

function getUserServerSnapshot(): string {
  return JSON.stringify(DEMO_USERS[0]);
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const userJson = useSyncExternalStore(subscribeUser, getUserSnapshot, getUserServerSnapshot);
  const currentUser = useMemo<User | null>(() => {
    try {
      return JSON.parse(userJson);
    } catch {
      return DEMO_USERS[0];
    }
  }, [userJson]);

  const setCurrentUser = useCallback((user: User | null) => {
    if (user) {
      cachedUserStr = JSON.stringify(user);
      try {
        localStorage.setItem('cso_current_user', cachedUserStr);
      } catch {
        // fallback
      }
    } else {
      cachedUserStr = JSON.stringify(DEMO_USERS[0]);
      try {
        localStorage.removeItem('cso_current_user');
      } catch {
        // fallback
      }
    }
    notifyUser();
  }, []);

  const [members, setMembers] = useState<OrgMember[]>(INITIAL_MEMBERS);
  const [certificates, setCertificates] = useState<Certificate[]>(INITIAL_CERTIFICATES);
  const [tickets, setTickets] = useState<HelpTicket[]>(INITIAL_TICKETS);
  const [incidents, setIncidents] = useState<IncidentReport[]>(INITIAL_INCIDENT_REPORTS);
  const [courses, setCourses] = useState<Course[]>(INITIAL_COURSES);
  const [articles, setArticles] = useState<Article[]>(INITIAL_ARTICLES);
  const [events, setEvents] = useState<EventItem[]>(INITIAL_EVENTS);
  const [eventRegistrations, setEventRegistrations] = useState<EventRegistration[]>([
    {
      id: 'reg-1',
      eventId: 'evt-1',
      eventTitle: 'CyberShield CTF 2026',
      name: 'Tanvir Ahmed',
      email: 'student@example.edu',
      phone: '+8801700112233',
      institution: 'University of Dhaka',
      registeredAt: '2026-08-14T09:00:00Z',
      ticketNumber: 'TKT-CTF-2026-049',
    }
  ]);
  const [volunteerApplications, setVolunteerApplications] = useState<VolunteerApplication[]>([
    {
      id: 'app-vol-1',
      type: 'CAMPUS_REP',
      name: 'Sadia Afrin',
      email: 'sadia.afrin@sust.edu',
      phone: '+8801811223344',
      institution: 'Shahjalal University of Science and Technology',
      department: 'Software Engineering',
      academicYear: '3rd Year',
      cyberInterest: 'Incident Triage & Web Application Security',
      statement: 'I want to build a cybersecurity awareness culture at SUST and organize local hands-on CTFs.',
      status: 'SHORTLISTED',
      appliedAt: '2026-08-10T11:00:00Z',
      notes: 'Strong academic record and active participation in university coding club.',
    }
  ]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [faqs, setFaqs] = useState<FAQItem[]>(INITIAL_FAQS);
  const [partners, setPartners] = useState<Partner[]>(INITIAL_PARTNERS);
  const [completedLessonIds, setCompletedLessonIds] = useState<string[]>(['les-1-1']);
  const [safetyScore, setSafetyScore] = useState<number>(75);

  const [chats, setChats] = useState<ChatConversation[]>([
    {
      id: 'chat-demo-1',
      studentName: 'Tanvir Ahmed (DU Student)',
      studentEmail: 'tanvir.cs@du.ac.bd',
      ticketId: 'CSO-HLP-82741',
      status: 'ACTIVE',
      assignedAgentName: 'Nusrat Jahan Chowdhury',
      assignedAgentId: 'user-agent',
      unreadCount: 0,
      lastMessage: 'We have compiled the formal emergency memo for your ICT Cell.',
      lastMessageTimestamp: '2026-08-14T11:25:00Z',
      messages: [
        {
          id: 'cmsg-1',
          conversationId: 'chat-demo-1',
          senderId: 'tanvir',
          senderName: 'Tanvir Ahmed',
          senderType: 'student',
          message: 'Hello, my university email was compromised via a fake stipend portal. I need immediate guidance on revoking the attacker session.',
          timestamp: '2026-08-14T10:16:00Z',
          isRead: true,
        },
        {
          id: 'cmsg-2',
          conversationId: 'chat-demo-1',
          senderId: 'user-agent',
          senderName: 'Nusrat Jahan Chowdhury (Support Desk)',
          senderType: 'agent',
          message: 'Hi Tanvir! Please do not panic. Under no circumstances share any passwords or OTPs here. We are generating an official incident document with IoCs for your departmental admin.',
          timestamp: '2026-08-14T10:18:00Z',
          isRead: true,
        }
      ]
    }
  ]);
  const [activeChat, setActiveChat] = useState<ChatConversation | null>(null);

  // Save changes
  const saveState = (key: string, data: unknown) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch {
      // safe fallback
    }
  };

  const addAuditLog = (action: string, resource: string, resourceId: string, details: string) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      actor: currentUser ? `${currentUser.name} (${currentUser.role})` : 'Anonymous Student',
      actorRole: currentUser?.role || 'GUEST',
      action,
      resource,
      resourceId,
      ipAddress: '103.114.152.18',
      timestamp: new Date().toISOString(),
      details,
    };
    setAuditLogs(prev => {
      const updated = [newLog, ...prev];
      saveState('cso_audit_logs', updated);
      return updated;
    });
  };

  const switchRole = (role: User['role']) => {
    const found = DEMO_USERS.find(u => u.role === role) || {
      id: `user-${role.toLowerCase()}`,
      name: role === 'STUDENT' ? 'Tanvir Ahmed' : role === 'SUPPORT_AGENT' ? 'Nusrat Jahan' : 'Super Admin',
      email: `${role.toLowerCase()}@cybersafestudent.org`,
      role,
      institution: 'University of Dhaka',
      createdAt: new Date().toISOString(),
    };
    setCurrentUser(found);
    saveState('cso_current_user', found);
    addAuditLog('ROLE_SWITCH', 'UserSession', found.id, `User switched session view to role ${role}`);
  };

  const submitHelpTicket = (data: {
    studentName: string;
    studentEmail: string;
    studentPhone?: string;
    isAnonymous: boolean;
    category: IncidentCategory;
    title: string;
    description: string;
    platformInvolved: string;
    incidentDate: string;
    severity: TicketPriority;
    evidenceFiles?: { name: string; size: string; type: string }[];
  }) => {
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const ticketId = `CSO-HLP-${randomNum}`;
    const now = new Date().toISOString();

    const newTicket: HelpTicket = {
      id: ticketId,
      studentName: data.isAnonymous ? 'Anonymous Student' : data.studentName,
      studentEmail: data.isAnonymous ? 'help-protected@temporary.cso' : data.studentEmail,
      studentPhone: data.studentPhone,
      isAnonymous: data.isAnonymous,
      category: data.category,
      title: data.title,
      description: data.description,
      platformInvolved: data.platformInvolved,
      incidentDate: data.incidentDate,
      severity: data.severity,
      status: 'NEW',
      priority: data.severity,
      createdAt: now,
      updatedAt: now,
      messages: [
        {
          id: `msg-${Date.now()}`,
          ticketId,
          senderId: currentUser?.id || 'guest',
          senderName: data.isAnonymous ? 'Anonymous Student' : data.studentName,
          senderRole: 'Student',
          message: data.description,
          timestamp: now,
        }
      ],
      timeline: [
        {
          id: `time-${Date.now()}`,
          action: 'Ticket Created & Queued for Triage',
          performedBy: data.isAnonymous ? 'Anonymous Requester' : data.studentName,
          timestamp: now,
        }
      ],
      evidenceFiles: data.evidenceFiles,
    };

    setTickets(prev => {
      const updated = [newTicket, ...prev];
      saveState('cso_tickets', updated);
      return updated;
    });

    addAuditLog('TICKET_CREATED', 'HelpTicket', ticketId, `New ${data.severity} severity ticket submitted under category ${data.category}`);
    
    // Auto add notification
    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        title: `Help Ticket ${ticketId} Created`,
        message: `Your request has been securely queued. A CSO triage specialist will respond shortly.`,
        type: 'TICKET',
        timestamp: now,
        isRead: false,
        linkUrl: `/help-center/track?id=${ticketId}`
      },
      ...prev
    ]);

    return ticketId;
  };

  const addTicketMessage = (ticketId: string, message: string, isInternalNote = false) => {
    const now = new Date().toISOString();
    const newMsg: TicketMessage = {
      id: `msg-${Date.now()}`,
      ticketId,
      senderId: currentUser?.id || 'agent',
      senderName: currentUser?.name || 'Support Agent',
      senderRole: currentUser?.role || 'Support Agent',
      message,
      timestamp: now,
      isInternalNote,
    };

    setTickets(prev => {
      const updated = prev.map(t => {
        if (t.id === ticketId) {
          return {
            ...t,
            updatedAt: now,
            messages: [...t.messages, newMsg],
            timeline: [
              ...t.timeline,
              {
                id: `time-${Date.now()}`,
                action: isInternalNote ? 'Internal Note Added' : 'Message Sent to Requester',
                performedBy: currentUser?.name || 'Support Agent',
                timestamp: now,
              }
            ]
          };
        }
        return t;
      });
      saveState('cso_tickets', updated);
      return updated;
    });

    addAuditLog(isInternalNote ? 'TICKET_INTERNAL_NOTE' : 'TICKET_REPLY', 'HelpTicket', ticketId, `Added message to ticket ${ticketId}`);
  };

  const updateTicketStatus = (ticketId: string, status: TicketStatus, notes?: string) => {
    const now = new Date().toISOString();
    setTickets(prev => {
      const updated = prev.map(t => {
        if (t.id === ticketId) {
          return {
            ...t,
            status,
            updatedAt: now,
            timeline: [
              ...t.timeline,
              {
                id: `time-${Date.now()}`,
                action: `Status changed to ${status}`,
                performedBy: currentUser?.name || 'Staff',
                timestamp: now,
                notes,
              }
            ]
          };
        }
        return t;
      });
      saveState('cso_tickets', updated);
      return updated;
    });
    addAuditLog('TICKET_STATUS_CHANGED', 'HelpTicket', ticketId, `Updated status to ${status}. ${notes || ''}`);
  };

  const assignTicketAgent = (ticketId: string, agentName: string) => {
    const now = new Date().toISOString();
    setTickets(prev => {
      const updated = prev.map(t => {
        if (t.id === ticketId) {
          return {
            ...t,
            assignedAgentName: agentName,
            updatedAt: now,
            timeline: [
              ...t.timeline,
              {
                id: `time-${Date.now()}`,
                action: `Assigned to ${agentName}`,
                performedBy: currentUser?.name || 'Lead Admin',
                timestamp: now,
              }
            ]
          };
        }
        return t;
      });
      saveState('cso_tickets', updated);
      return updated;
    });
    addAuditLog('TICKET_ASSIGNED', 'HelpTicket', ticketId, `Assigned ticket to agent ${agentName}`);
  };

  const submitIncidentReport = (data: {
    reporterName?: string;
    reporterEmail?: string;
    isAnonymous: boolean;
    category: IncidentCategory;
    targetPlatform: string;
    incidentDate: string;
    impactedUrlOrAccount?: string;
    threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    description: string;
  }) => {
    const randomNum = Math.floor(100 + Math.random() * 900);
    const incidentId = `CSO-INC-2026-${randomNum}`;
    const now = new Date().toISOString();

    const newReport: IncidentReport = {
      id: incidentId,
      reporterName: data.isAnonymous ? 'Anonymous Reporter' : data.reporterName,
      reporterEmail: data.isAnonymous ? undefined : data.reporterEmail,
      isAnonymous: data.isAnonymous,
      category: data.category,
      targetPlatform: data.targetPlatform,
      incidentDate: data.incidentDate,
      impactedUrlOrAccount: data.impactedUrlOrAccount,
      threatLevel: data.threatLevel,
      description: data.description,
      status: 'SUBMITTED',
      guidanceGiven: 'Report received. Our threat intel desk has logged IoCs. Standard forensic preservation instructions issued.',
      lawEnforcementAdvised: data.threatLevel === 'CRITICAL' || data.threatLevel === 'HIGH',
      createdAt: now,
      evidenceCount: 1,
    };

    setIncidents(prev => {
      const updated = [newReport, ...prev];
      saveState('cso_incidents', updated);
      return updated;
    });

    addAuditLog('INCIDENT_REPORTED', 'IncidentReport', incidentId, `Threat level ${data.threatLevel} incident submitted`);
    return incidentId;
  };

  const updateMemberStatus = (memberId: string, status: MemberStatus, reason?: string) => {
    setMembers(prev => {
      const updated = prev.map(m => {
        if (m.id === memberId) {
          return {
            ...m,
            status,
            statusReason: reason || m.statusReason,
            lastVerifiedAt: new Date().toISOString(),
          };
        }
        return m;
      });
      saveState('cso_members', updated);
      return updated;
    });
    addAuditLog('MEMBER_STATUS_CHANGED', 'OrgMember', memberId, `Member status updated to ${status}. Reason: ${reason || 'N/A'}`);
  };

  const addMember = (member: OrgMember) => {
    setMembers(prev => {
      const updated = [member, ...prev];
      saveState('cso_members', updated);
      return updated;
    });
    addAuditLog('MEMBER_CREATED', 'OrgMember', member.id, `New member profile created for ${member.name}`);
  };

  const updateCertificateStatus = (certId: string, status: CertificateStatus) => {
    setCertificates(prev => {
      const updated = prev.map(c => {
        if (c.id === certId) {
          return { ...c, status };
        }
        return c;
      });
      saveState('cso_certs', updated);
      return updated;
    });
    addAuditLog('CERTIFICATE_STATUS_CHANGED', 'Certificate', certId, `Status updated to ${status}`);
  };

  const issueCertificate = (cert: Omit<Certificate, 'id' | 'hashSignature'>) => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const certId = `CSO-CERT-2026-${randomNum}`;
    const hash = `sha256:${Math.random().toString(36).substring(2)}${Date.now().toString(16)}`;

    const newCert: Certificate = {
      ...cert,
      id: certId,
      hashSignature: hash,
    };

    setCertificates(prev => {
      const updated = [newCert, ...prev];
      saveState('cso_certs', updated);
      return updated;
    });

    addAuditLog('CERTIFICATE_ISSUED', 'Certificate', certId, `Certificate issued to ${cert.recipientName} for ${cert.courseOrEventTitle}`);
    return certId;
  };

  const registerForEvent = (eventId: string, name: string, email: string, phone: string, institution: string) => {
    const event = events.find(e => e.id === eventId);
    const regId = `reg-${Date.now()}`;
    const ticketNum = `TKT-${event?.type || 'EVT'}-2026-${Math.floor(100 + Math.random() * 900)}`;

    const newReg: EventRegistration = {
      id: regId,
      eventId,
      eventTitle: event?.title || 'CyberSafe Event',
      name,
      email,
      phone,
      institution,
      registeredAt: new Date().toISOString(),
      ticketNumber: ticketNum,
    };

    setEventRegistrations(prev => [newReg, ...prev]);
    setEvents(prev => prev.map(e => e.id === eventId ? { ...e, registeredCount: e.registeredCount + 1 } : e));

    addAuditLog('EVENT_REGISTRATION', 'EventRegistration', regId, `Registered for event ${event?.title}`);
    return ticketNum;
  };

  const submitVolunteerApplication = (app: Omit<VolunteerApplication, 'id' | 'status' | 'appliedAt'>) => {
    const appId = `app-${Date.now()}`;
    const newApp: VolunteerApplication = {
      ...app,
      id: appId,
      status: 'SUBMITTED',
      appliedAt: new Date().toISOString(),
    };

    setVolunteerApplications(prev => [newApp, ...prev]);
    addAuditLog('VOLUNTEER_APPLIED', 'VolunteerApplication', appId, `Application submitted by ${app.name} (${app.type})`);
    return appId;
  };

  const updateVolunteerStatus = (id: string, status: VolunteerApplication['status']) => {
    setVolunteerApplications(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    addAuditLog('VOLUNTEER_STATUS_UPDATED', 'VolunteerApplication', id, `Updated status to ${status}`);
  };

  const completeLesson = (lessonId: string) => {
    setCompletedLessonIds(prev => {
      if (prev.includes(lessonId)) return prev;
      const updated = [...prev, lessonId];
      saveState('cso_completed_lessons', updated);
      return updated;
    });
  };

  const setSafetyScoreVal = (score: number) => {
    setSafetyScore(score);
    saveState('cso_safety_score', score);
  };

  // Live Chat
  const startOrGetChat = (studentName: string, studentEmail?: string, ticketId?: string) => {
    const existing = chats.find(c => c.studentEmail === studentEmail || (ticketId && c.ticketId === ticketId));
    if (existing) {
      setActiveChat(existing);
      return existing;
    }

    const newChat: ChatConversation = {
      id: `chat-${Date.now()}`,
      studentName,
      studentEmail,
      ticketId,
      status: 'ACTIVE',
      assignedAgentName: 'Nusrat Jahan Chowdhury (Incident Desk)',
      assignedAgentId: 'agent-1',
      unreadCount: 0,
      lastMessage: 'Chat session initiated. Support agent connected.',
      lastMessageTimestamp: new Date().toISOString(),
      messages: [
        {
          id: `cmsg-${Date.now()}`,
          conversationId: `chat-${Date.now()}`,
          senderId: 'system',
          senderName: 'CyberSafe Sentinel Bot',
          senderType: 'system',
          message: 'Connected to CSO Student Incident Response Desk. Please never share passwords or 2FA codes. An agent is online.',
          timestamp: new Date().toISOString(),
          isRead: true,
        }
      ]
    };

    setChats(prev => [newChat, ...prev]);
    setActiveChat(newChat);
    return newChat;
  };

  const sendLiveChatMessage = (conversationId: string, message: string, senderType: 'student' | 'agent' = 'student') => {
    const now = new Date().toISOString();
    const newMsg: LiveChatMessage = {
      id: `cmsg-${Date.now()}`,
      conversationId,
      senderId: currentUser?.id || 'guest',
      senderName: senderType === 'agent' ? (currentUser?.name || 'Support Agent') : (currentUser?.name || 'Student'),
      senderType,
      message,
      timestamp: now,
      isRead: false,
    };

    setChats(prev => prev.map(c => {
      if (c.id === conversationId) {
        return {
          ...c,
          lastMessage: message,
          lastMessageTimestamp: now,
          messages: [...c.messages, newMsg]
        };
      }
      return c;
    }));

    if (activeChat && activeChat.id === conversationId) {
      setActiveChat(prev => prev ? {
        ...prev,
        lastMessage: message,
        lastMessageTimestamp: now,
        messages: [...prev.messages, newMsg]
      } : null);
    }

    // If student sends message, generate smart auto-triage response if simulated
    if (senderType === 'student') {
      setTimeout(() => {
        const automatedReply: LiveChatMessage = {
          id: `cmsg-reply-${Date.now()}`,
          conversationId,
          senderId: 'agent-1',
          senderName: 'Nusrat Jahan Chowdhury (CSO Incident Lead)',
          senderType: 'agent',
          message: `Thank you for the update. Our incident triage desk has received your note. Please preserve all screenshot headers and avoid clicking any links sent by the suspicious account.`,
          timestamp: new Date().toISOString(),
          isRead: true,
        };
        setChats(currChats => currChats.map(c => {
          if (c.id === conversationId) {
            return {
              ...c,
              lastMessage: automatedReply.message,
              lastMessageTimestamp: automatedReply.timestamp,
              messages: [...c.messages, automatedReply]
            };
          }
          return c;
        }));
        if (activeChat && activeChat.id === conversationId) {
          setActiveChat(prev => prev ? {
            ...prev,
            lastMessage: automatedReply.message,
            lastMessageTimestamp: automatedReply.timestamp,
            messages: [...prev.messages, automatedReply]
          } : null);
        }
      }, 1400);
    }
  };

  // CMS
  const createArticle = (art: Omit<Article, 'id' | 'publishedAt'>) => {
    const newArt: Article = {
      ...art,
      id: `art-${Date.now()}`,
      publishedAt: new Date().toISOString(),
    };
    setArticles(prev => [newArt, ...prev]);
    addAuditLog('ARTICLE_CREATED', 'Article', newArt.id, `Created article "${art.title}"`);
  };

  const updateArticle = (id: string, art: Partial<Article>) => {
    setArticles(prev => prev.map(a => a.id === id ? { ...a, ...art } : a));
    addAuditLog('ARTICLE_UPDATED', 'Article', id, `Updated article`);
  };

  const deleteArticle = (id: string) => {
    setArticles(prev => prev.filter(a => a.id !== id));
    addAuditLog('ARTICLE_DELETED', 'Article', id, `Deleted article`);
  };

  const createCourse = (c: Omit<Course, 'id'>) => {
    const newCourse: Course = {
      ...c,
      id: `course-${Date.now()}`,
    };
    setCourses(prev => [newCourse, ...prev]);
    addAuditLog('COURSE_CREATED', 'Course', newCourse.id, `Created course "${c.title}"`);
  };

  const updateCourse = (id: string, c: Partial<Course>) => {
    setCourses(prev => prev.map(item => item.id === id ? { ...item, ...c } : item));
    addAuditLog('COURSE_UPDATED', 'Course', id, `Updated course`);
  };

  const createEvent = (e: Omit<EventItem, 'id'>) => {
    const newEvent: EventItem = {
      ...e,
      id: `evt-${Date.now()}`,
    };
    setEvents(prev => [newEvent, ...prev]);
    addAuditLog('EVENT_CREATED', 'EventItem', newEvent.id, `Created event "${e.title}"`);
  };

  const updateEvent = (id: string, e: Partial<EventItem>) => {
    setEvents(prev => prev.map(item => item.id === id ? { ...item, ...e } : item));
    addAuditLog('EVENT_UPDATED', 'EventItem', id, `Updated event`);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const resetToDefaults = () => {
    setMembers(INITIAL_MEMBERS);
    setCertificates(INITIAL_CERTIFICATES);
    setTickets(INITIAL_TICKETS);
    setIncidents(INITIAL_INCIDENT_REPORTS);
    setCourses(INITIAL_COURSES);
    setArticles(INITIAL_ARTICLES);
    setEvents(INITIAL_EVENTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setNotifications(INITIAL_NOTIFICATIONS);
    localStorage.clear();
    addAuditLog('SYSTEM_RESET', 'System', 'ALL', 'Reset platform store to pristine default state');
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      setCurrentUser,
      switchRole,
      members,
      certificates,
      tickets,
      incidents,
      courses,
      articles,
      events,
      eventRegistrations,
      volunteerApplications,
      auditLogs,
      notifications,
      faqs,
      partners,
      chats,
      activeChat,
      completedLessonIds,
      safetyScore,
      submitHelpTicket,
      addTicketMessage,
      updateTicketStatus,
      assignTicketAgent,
      submitIncidentReport,
      updateMemberStatus,
      addMember,
      updateCertificateStatus,
      issueCertificate,
      registerForEvent,
      submitVolunteerApplication,
      updateVolunteerStatus,
      completeLesson,
      setSafetyScore: setSafetyScoreVal,
      sendLiveChatMessage,
      startOrGetChat,
      setActiveChat,
      createArticle,
      updateArticle,
      deleteArticle,
      createCourse,
      updateCourse,
      createEvent,
      updateEvent,
      markNotificationRead,
      markAllNotificationsRead,
      addAuditLog,
      resetToDefaults,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
