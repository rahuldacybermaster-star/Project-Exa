export interface User {
  id: string;
  name: string;
  email: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'SUPPORT_AGENT' | 'CONTENT_MANAGER' | 'VERIFICATION_OFFICER' | 'STUDENT' | 'GUEST';
  institution?: string;
  avatar?: string;
  createdAt: string;
  twoFactorEnabled?: boolean;
}

export type TicketStatus = 
  | 'NEW' 
  | 'UNDER_REVIEW' 
  | 'NEED_INFORMATION' 
  | 'IN_PROGRESS' 
  | 'WAITING_FOR_USER' 
  | 'RESOLVED' 
  | 'CLOSED' 
  | 'REJECTED';

export type TicketPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type IncidentCategory = 
  | 'ACCOUNT_HACKING'
  | 'PHISHING'
  | 'ONLINE_SCAM'
  | 'FAKE_ACCOUNT'
  | 'CYBERBULLYING'
  | 'ONLINE_HARASSMENT'
  | 'THREATS'
  | 'PRIVACY_MISUSE'
  | 'SUSPICIOUS_WEBSITE'
  | 'MALWARE_DEVICE'
  | 'IDENTITY_THEFT'
  | 'OTHER';

export interface TicketMessage {
  id: string;
  ticketId: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  message: string;
  timestamp: string;
  isInternalNote?: boolean;
  attachments?: { name: string; size: string; type: string; url?: string }[];
}

export interface TicketTimelineItem {
  id: string;
  action: string;
  performedBy: string;
  timestamp: string;
  notes?: string;
}

export interface HelpTicket {
  id: string; // e.g. CSO-HLP-82741
  studentName: string;
  studentEmail: string;
  studentPhone?: string;
  isAnonymous: boolean;
  category: IncidentCategory;
  title: string;
  description: string;
  platformInvolved: string; // e.g. "Facebook", "Gmail", "WhatsApp", "Telegram", "Instagram"
  incidentDate: string;
  severity: TicketPriority;
  status: TicketStatus;
  priority: TicketPriority;
  assignedAgentId?: string;
  assignedAgentName?: string;
  createdAt: string;
  updatedAt: string;
  resolutionSummary?: string;
  messages: TicketMessage[];
  timeline: TicketTimelineItem[];
  evidenceFiles?: { name: string; size: string; type: string }[];
}

export interface LiveChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderType: 'student' | 'agent' | 'system';
  message: string;
  timestamp: string;
  isRead: boolean;
  attachments?: { name: string; url: string; type: string }[];
}

export interface ChatConversation {
  id: string;
  studentName: string;
  studentEmail?: string;
  ticketId?: string;
  status: 'ACTIVE' | 'WAITING' | 'CLOSED';
  assignedAgentName?: string;
  assignedAgentId?: string;
  unreadCount: number;
  lastMessage: string;
  lastMessageTimestamp: string;
  messages: LiveChatMessage[];
}

export interface IncidentReport {
  id: string; // e.g. CSO-INC-2026-00124
  reporterName?: string;
  reporterEmail?: string;
  isAnonymous: boolean;
  category: IncidentCategory;
  targetPlatform: string;
  incidentDate: string;
  impactedUrlOrAccount?: string;
  threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  status: 'SUBMITTED' | 'TRIAGED' | 'EVIDENCE_PRESERVED' | 'AUTHORITY_REFERRED' | 'RESOLVED';
  guidanceGiven: string;
  lawEnforcementAdvised: boolean;
  createdAt: string;
  evidenceCount: number;
}

export type MemberStatus = 'ACTIVE' | 'PENDING' | 'SUSPENDED' | 'EXPIRED' | 'REVOKED';

export interface OrgMember {
  id: string; // e.g. CSO-BD-000124
  name: string;
  banglaName?: string;
  role: string;
  department: string;
  position: string;
  institution: string;
  status: MemberStatus;
  joinedDate: string;
  validUntil: string;
  avatar: string;
  badgeType: 'Core Executive' | 'Campus Director' | 'Cyber Security Trainer' | 'Senior Volunteer' | 'Researcher';
  statusReason?: string;
  lastVerifiedAt?: string;
}

export type CertificateStatus = 'VALID' | 'EXPIRED' | 'REVOKED';

export interface Certificate {
  id: string; // e.g. CSO-CERT-2026-8941
  recipientName: string;
  recipientEmail: string;
  courseOrEventTitle: string;
  type: 'COURSE_COMPLETION' | 'CTF_WINNER' | 'WORKSHOP_ATTENDANCE' | 'VOLUNTEER_MERIT';
  issueDate: string;
  validUntil?: string;
  status: CertificateStatus;
  gradeScore?: string; // e.g. "96% Distinction"
  issuerName: string;
  issuerDesignation: string;
  hashSignature: string;
}

export interface CourseLesson {
  id: string;
  title: string;
  duration: string;
  content: string;
  videoUrl?: string;
  isCompleted?: boolean;
}

export interface CourseModule {
  id: string;
  title: string;
  lessons: CourseLesson[];
}

export interface QuizOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: QuizOption[];
  explanation: string;
}

export interface CourseQuiz {
  id: string;
  passingScore: number;
  questions: QuizQuestion[];
}

export interface Course {
  id: string;
  slug: string;
  title: string;
  description: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  modulesCount: number;
  enrolledCount: number;
  rating: number;
  category: string;
  instructor: string;
  instructorRole: string;
  isPublished: boolean;
  thumbnail: string;
  modules: CourseModule[];
  quiz?: CourseQuiz;
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  banglaTitle?: string;
  category: 'Security Alert' | 'Phishing Guide' | 'Social Media Safety' | 'Incident Response' | 'Privacy' | 'Malware Analysis';
  excerpt: string;
  content: string;
  author: string;
  authorRole: string;
  publishedAt: string;
  readTime: string;
  isAlert?: boolean;
  tags: string[];
  thumbnail: string;
  isPublished: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  slug: string;
  type: 'CTF' | 'WORKSHOP' | 'SEMINAR' | 'TRAINING' | 'CAMPAIGN';
  date: string;
  time: string;
  location: string;
  isOnline: boolean;
  meetingLinkOrVenue: string;
  capacity: number;
  registeredCount: number;
  status: 'UPCOMING' | 'ONGOING' | 'COMPLETED';
  description: string;
  speakers: { name: string; role: string; org: string }[];
  thumbnail: string;
}

export interface EventRegistration {
  id: string;
  eventId: string;
  eventTitle: string;
  name: string;
  email: string;
  phone: string;
  institution: string;
  registeredAt: string;
  ticketNumber: string;
}

export interface VolunteerApplication {
  id: string;
  type: 'VOLUNTEER' | 'CAMPUS_REP';
  name: string;
  email: string;
  phone: string;
  institution: string;
  department: string;
  academicYear: string;
  cyberInterest: string;
  statement: string;
  status: 'SUBMITTED' | 'UNDER_REVIEW' | 'SHORTLISTED' | 'ACCEPTED' | 'REJECTED';
  appliedAt: string;
  notes?: string;
}

export interface AuditLog {
  id: string;
  actor: string;
  actorRole: string;
  action: string;
  resource: string;
  resourceId: string;
  ipAddress: string;
  timestamp: string;
  details: string;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  title: string;
  message: string;
  type: 'TICKET' | 'SECURITY_ALERT' | 'EVENT' | 'CERTIFICATE' | 'SYSTEM';
  timestamp: string;
  isRead: boolean;
  linkUrl?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  banglaQuestion?: string;
  answer: string;
  banglaAnswer?: string;
  category: 'Account Safety' | 'Help Requests' | 'Phishing & Scams' | 'Member Verification' | 'CTF & Events';
}

export interface Partner {
  id: string;
  name: string;
  type: 'Academic University' | 'Security NGO' | 'Tech Alliance' | 'Cyber Law Society';
  logoText: string;
  description: string;
  website: string;
}
