'use client';

import { 
  User, 
  HelpTicket, 
  LiveChatMessage, 
  ChatConversation, 
  IncidentReport, 
  OrgMember, 
  Certificate, 
  Course, 
  Article, 
  EventItem, 
  EventRegistration, 
  VolunteerApplication, 
  AuditLog, 
  NotificationItem, 
  FAQItem, 
  Partner 
} from './types';

export const INITIAL_MEMBERS: OrgMember[] = [
  {
    id: 'CSO-BD-000124',
    name: 'Abrar Tanveer Rahman',
    banglaName: 'আবরার তানভীর রহমান',
    role: 'President & Incident Lead',
    department: 'Executive Board',
    position: 'Chief of Cyber Operations',
    institution: 'Department of CSE, BUET',
    status: 'ACTIVE',
    joinedDate: '2024-01-15',
    validUntil: '2027-01-14',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    badgeType: 'Core Executive',
    lastVerifiedAt: '2026-08-15T09:30:00Z',
  },
  {
    id: 'CSO-BD-000189',
    name: 'Nusrat Jahan Chowdhury',
    banglaName: 'নুসরাত জাহান চৌধুরী',
    role: 'Lead Security Researcher',
    department: 'Threat Research & Triage',
    position: 'Head of Student Incident Response',
    institution: 'Institute of Information Technology, DU',
    status: 'ACTIVE',
    joinedDate: '2024-05-10',
    validUntil: '2026-12-31',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    badgeType: 'Researcher',
    lastVerifiedAt: '2026-08-14T14:15:00Z',
  },
  {
    id: 'CSO-BD-000215',
    name: 'Shakil Ahmed Khan',
    banglaName: 'শাকিল আহমেদ খান',
    role: 'Campus Representative Director',
    department: 'Campus Outreach',
    position: 'North South University Campus Lead',
    institution: 'School of Engineering, NSU',
    status: 'ACTIVE',
    joinedDate: '2024-09-01',
    validUntil: '2026-09-01',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    badgeType: 'Campus Director',
    lastVerifiedAt: '2026-08-10T11:00:00Z',
  },
  {
    id: 'CSO-BD-000302',
    name: 'Farhan Kabir Sourav',
    banglaName: 'ফারহান কবির সৌরভ',
    role: 'CTF Trainer & Workshop Mentor',
    department: 'Training & Academy',
    position: 'Offensive Security Specialist',
    institution: 'Computer Science, IUT',
    status: 'ACTIVE',
    joinedDate: '2025-02-01',
    validUntil: '2027-02-01',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    badgeType: 'Cyber Security Trainer',
    lastVerifiedAt: '2026-08-01T08:00:00Z',
  },
  {
    id: 'CSO-BD-000099',
    name: 'Rafidul Islam (Terminated)',
    banglaName: 'রাফিদুল ইসলাম',
    role: 'Ex-Volunteer',
    department: 'Outreach',
    position: 'Former Assistant',
    institution: 'Independent University, Bangladesh',
    status: 'REVOKED',
    joinedDate: '2023-03-01',
    validUntil: '2024-03-01',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&auto=format&fit=crop&q=80',
    badgeType: 'Senior Volunteer',
    statusReason: 'Revoked due to organizational code of conduct breach and unauthorized third-party representation.',
    lastVerifiedAt: '2026-07-20T16:00:00Z',
  },
  {
    id: 'CSO-BD-000155',
    name: 'Tasnim Ferdous',
    banglaName: 'তাসনিম ফেরদৌস',
    role: 'Alumni Ambassador',
    department: 'Public Relations',
    position: 'Former Campus Ambassador',
    institution: 'BRAC University',
    status: 'EXPIRED',
    joinedDate: '2024-01-01',
    validUntil: '2025-06-30',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
    badgeType: 'Senior Volunteer',
    statusReason: 'Membership tenure completed. Re-application required for current term.',
    lastVerifiedAt: '2025-07-01T10:00:00Z',
  },
];

export const INITIAL_CERTIFICATES: Certificate[] = [
  {
    id: 'CSO-CERT-2026-8941',
    recipientName: 'Samiul Hasan Ridoy',
    recipientEmail: 'samiul.ridoy@example.edu',
    courseOrEventTitle: 'Defensive Cyber Hygiene & Incident Triage Masterclass',
    type: 'COURSE_COMPLETION',
    issueDate: '2026-04-12',
    validUntil: '2029-04-12',
    status: 'VALID',
    gradeScore: '98% Distinction',
    issuerName: 'Abrar Tanveer Rahman',
    issuerDesignation: 'Lead Incident Commander, CSO',
    hashSignature: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  },
  {
    id: 'CSO-CERT-2026-9012',
    recipientName: 'Mahira Anjum',
    recipientEmail: 'mahira.cyber@example.edu',
    courseOrEventTitle: 'National Student CTF 2026 - First Runner Up',
    type: 'CTF_WINNER',
    issueDate: '2026-06-20',
    status: 'VALID',
    gradeScore: 'Rank #2 (2,450 pts)',
    issuerName: 'Farhan Kabir Sourav',
    issuerDesignation: 'CTF Director, CSO',
    hashSignature: 'sha256:88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589',
  },
  {
    id: 'CSO-CERT-2025-0432',
    recipientName: 'Jubair Al Mahmud',
    recipientEmail: 'jubair.invalid@example.com',
    courseOrEventTitle: 'Practical Social Engineering Defense',
    type: 'WORKSHOP_ATTENDANCE',
    issueDate: '2025-08-10',
    status: 'REVOKED',
    gradeScore: 'Revoked',
    issuerName: 'Executive Council',
    issuerDesignation: 'Verification Desk',
    hashSignature: 'sha256:invalid_certificate_checksum_revoked',
  },
];

export const INITIAL_TICKETS: HelpTicket[] = [
  {
    id: 'CSO-HLP-82741',
    studentName: 'Tanvir Ahmed (DU Student)',
    studentEmail: 'tanvir.cs@du.ac.bd',
    studentPhone: '+8801700112233',
    isAnonymous: false,
    category: 'PHISHING',
    title: 'Received targeted university scholarship phishing link & entered Gmail login',
    description: 'Yesterday I received an email from an address pretending to be DU Registrar offering a merit laptop stipend. I clicked the link and entered my university email and password on a clone login page. Within 2 hours, my recovery email was changed and suspicious spam was sent from my account.',
    platformInvolved: 'Google Workspace / Gmail',
    incidentDate: '2026-08-14',
    severity: 'HIGH',
    status: 'IN_PROGRESS',
    priority: 'HIGH',
    assignedAgentId: 'agent-1',
    assignedAgentName: 'Nusrat Jahan Chowdhury',
    createdAt: '2026-08-14T10:15:00Z',
    updatedAt: '2026-08-15T06:40:00Z',
    messages: [
      {
        id: 'msg-1',
        ticketId: 'CSO-HLP-82741',
        senderId: 'tanvir-1',
        senderName: 'Tanvir Ahmed',
        senderRole: 'Student',
        message: 'Please help, the attacker enabled an unfamiliar 2FA authenticator app and I am locked out of my departmental submissions!',
        timestamp: '2026-08-14T10:15:00Z',
      },
      {
        id: 'msg-2',
        ticketId: 'CSO-HLP-82741',
        senderId: 'agent-1',
        senderName: 'Nusrat Jahan Chowdhury (CSO Incident Lead)',
        senderRole: 'Support Agent',
        message: 'Hello Tanvir. Do not panic. Since this is an institutional domain (@du.ac.bd), your university ICT Cell super-admins have supreme authority to revoke malicious sessions and reset your 2FA hardware keys. We have drafted a high-priority incident memo you can bring directly to the DU ICT Cell in Curzon Hall.',
        timestamp: '2026-08-14T11:20:00Z',
      },
      {
        id: 'msg-3',
        ticketId: 'CSO-HLP-82741',
        senderId: 'agent-1',
        senderName: 'Nusrat Jahan Chowdhury',
        senderRole: 'Support Agent',
        isInternalNote: true,
        message: 'Phishing domain observed: `du-stipend-portal-auth.online`. Reported to PhishTank and Cloudflare Abuse. Institutional abuse contact alerted.',
        timestamp: '2026-08-14T11:25:00Z',
      }
    ],
    timeline: [
      {
        id: 'time-1',
        action: 'Ticket Created',
        performedBy: 'Tanvir Ahmed',
        timestamp: '2026-08-14T10:15:00Z',
      },
      {
        id: 'time-2',
        action: 'Assigned to Nusrat Jahan Chowdhury',
        performedBy: 'System Auto-Triage',
        timestamp: '2026-08-14T10:18:00Z',
      },
      {
        id: 'time-3',
        action: 'Severity Escalated to HIGH',
        performedBy: 'Nusrat Jahan Chowdhury',
        timestamp: '2026-08-14T11:15:00Z',
        notes: 'Active session hijack on institutional email.',
      }
    ],
    evidenceFiles: [
      { name: 'phishing_email_header.eml', size: '42 KB', type: 'message/rfc822' },
      { name: 'fake_login_screenshot.png', size: '310 KB', type: 'image/png' },
    ]
  },
  {
    id: 'CSO-HLP-49210',
    studentName: 'Anonymous Student',
    studentEmail: 'help-protected@temporary.cso',
    isAnonymous: true,
    category: 'CYBERBULLYING',
    title: 'Defamatory fake Instagram account using my photos and harassing classmates',
    description: 'Someone created an impersonation profile using my real photos from Facebook and is sending abusive messages to my college batchmates. I already reported it on Instagram 3 days ago but no automated action was taken.',
    platformInvolved: 'Instagram / Meta',
    incidentDate: '2026-08-12',
    severity: 'MEDIUM',
    status: 'WAITING_FOR_USER',
    priority: 'MEDIUM',
    assignedAgentId: 'agent-2',
    assignedAgentName: 'Abrar Tanveer Rahman',
    createdAt: '2026-08-12T14:00:00Z',
    updatedAt: '2026-08-14T18:00:00Z',
    messages: [
      {
        id: 'msg-101',
        ticketId: 'CSO-HLP-49210',
        senderId: 'anon-user',
        senderName: 'Anonymous Student',
        senderRole: 'Student',
        message: 'The fake account username is @target_fake_victim_2026. How do I get Meta to expedite impersonation takedown?',
        timestamp: '2026-08-12T14:00:00Z',
      },
      {
        id: 'msg-102',
        ticketId: 'CSO-HLP-49210',
        senderId: 'agent-2',
        senderName: 'Abrar Tanveer Rahman (CSO Operations)',
        senderRole: 'Support Agent',
        message: 'We have compiled the formal "Meta Impersonation Verification Form" guideline. You will need to upload an ID with matching name/photo through Instagram’s specific identity dispute link, rather than using the basic in-app report button.',
        timestamp: '2026-08-13T09:30:00Z',
      }
    ],
    timeline: [
      {
        id: 'time-101',
        action: 'Anonymous Ticket Submitted',
        performedBy: 'Student',
        timestamp: '2026-08-12T14:00:00Z',
      },
      {
        id: 'time-102',
        action: 'Impersonation escalation guidance provided',
        performedBy: 'Abrar Tanveer Rahman',
        timestamp: '2026-08-13T09:30:00Z',
      }
    ],
  },
  {
    id: 'CSO-HLP-11893',
    studentName: 'Zubair Hossain',
    studentEmail: 'zubair.h@sust.edu',
    isAnonymous: false,
    category: 'ONLINE_SCAM',
    title: 'Telegram Part-time Job Investment Scam (BKash Deposit Fraud)',
    description: 'Added to a Telegram group promising 30% daily return by rating YouTube videos. Deposited 5,000 BDT via bKash merchant payment. Now they demand 25,000 BDT to "unlock" the wallet.',
    platformInvolved: 'Telegram & Mobile Banking',
    incidentDate: '2026-08-11',
    severity: 'HIGH',
    status: 'RESOLVED',
    priority: 'HIGH',
    assignedAgentId: 'agent-1',
    assignedAgentName: 'Nusrat Jahan Chowdhury',
    createdAt: '2026-08-11T09:00:00Z',
    updatedAt: '2026-08-13T16:00:00Z',
    resolutionSummary: 'Guided user to preserve bKash transaction IDs, freeze further payments, file an official complaint with bKash helpline 16247, and file an online general diary (GD) via Dhaka/Sylhet Cyber Police helpline.',
    messages: [
      {
        id: 'msg-201',
        ticketId: 'CSO-HLP-11893',
        senderId: 'zubair',
        senderName: 'Zubair Hossain',
        senderRole: 'Student',
        message: 'Thank you CSO team, your quick warning prevented me from losing 25,000 BDT more.',
        timestamp: '2026-08-13T15:30:00Z',
      }
    ],
    timeline: [
      {
        id: 'time-201',
        action: 'Ticket Created',
        performedBy: 'Zubair Hossain',
        timestamp: '2026-08-11T09:00:00Z',
      },
      {
        id: 'time-202',
        action: 'Resolution Delivered & Ticket Closed',
        performedBy: 'Nusrat Jahan Chowdhury',
        timestamp: '2026-08-13T16:00:00Z',
      }
    ]
  }
];

export const INITIAL_INCIDENT_REPORTS: IncidentReport[] = [
  {
    id: 'CSO-INC-2026-00124',
    reporterName: 'Department Representative (CSE)',
    reporterEmail: 'rep.cse@aust.edu',
    isAnonymous: false,
    category: 'PHISHING',
    targetPlatform: 'Campus WiFi Portal & Telegram',
    incidentDate: '2026-08-14',
    impactedUrlOrAccount: 'http://aust-wifi-auth-login.ddns.net',
    threatLevel: 'HIGH',
    description: 'A rogue Wi-Fi hotspot named "AUST_CAMPUS_HIGH_SPEED" was deployed near the cafeteria capturing student portal credentials via evil twin attack.',
    status: 'AUTHORITY_REFERRED',
    guidanceGiven: 'Preserved BSSID & captive portal source code. Coordinated with university network administrators to blacklist rogue AP and issue campus-wide security broadcast.',
    lawEnforcementAdvised: true,
    createdAt: '2026-08-14T11:00:00Z',
    evidenceCount: 3,
  },
  {
    id: 'CSO-INC-2026-00125',
    reporterName: 'Anonymous Student',
    isAnonymous: true,
    category: 'ONLINE_SCAM',
    targetPlatform: 'Facebook Marketplace',
    incidentDate: '2026-08-13',
    threatLevel: 'MEDIUM',
    description: 'Fake seller advertising discounted engineering textbooks taking advance bKash money and blocking buyers immediately.',
    status: 'TRIAGED',
    guidanceGiven: 'Educated victim on avoiding advance payments, provided formal reporting template for Facebook commerce team and bKash fraud desk.',
    lawEnforcementAdvised: false,
    createdAt: '2026-08-13T16:20:00Z',
    evidenceCount: 2,
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course-1',
    slug: 'student-cyber-hygiene',
    title: 'Essential Student Cyber Defense & Account Hardening',
    description: 'Learn how to protect your Google, Facebook, WhatsApp, and university accounts from hijacking, social engineering, and session hijacking.',
    level: 'Beginner',
    duration: '2.5 Hours',
    modulesCount: 4,
    enrolledCount: 1420,
    rating: 4.9,
    category: 'Defensive Security',
    instructor: 'Abrar Tanveer Rahman',
    instructorRole: 'President, CSO & Incident Lead',
    isPublished: true,
    thumbnail: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80',
    modules: [
      {
        id: 'mod-1',
        title: 'Module 1: Passwords, Passkeys & Multi-Factor Authentication',
        lessons: [
          {
            id: 'les-1-1',
            title: 'Why SMS OTP Fails: SIM Swapping & SS7 Interception',
            duration: '15 mins',
            content: `SMS-based two-factor authentication is significantly more vulnerable than Hardware Keys (YubiKeys) or Authenticator Apps (TOTP) due to SIM-swap fraud, malware interception, and network vulnerabilities. 
            
Key takeaways:
1. Always migrate from SMS OTP to TOTP apps like Aegis, 2FAS, or Google Authenticator.
2. Generate and securely store offline printable backup codes in a physically secure place.
3. Enable Passkeys (FIDO2/WebAuthn) for cryptographic phishing immunity.`,
          },
          {
            id: 'les-1-2',
            title: 'Deploying Open-Source Password Managers (Bitwarden / KeePassXC)',
            duration: '20 mins',
            content: `Reusing passwords across student portals, social media, and gaming platforms is the #1 vector for credential stuffing attacks following third-party data breaches.

Setup recommendations:
- Use unique 16+ character passphrases for every single service.
- Secure your master password with high entropy.
- Periodically check HaveIBeenPwned for breached email addresses.`,
          }
        ]
      },
      {
        id: 'mod-2',
        title: 'Module 2: Phishing Anatomy & Evil Twin Wi-Fi Attacks',
        lessons: [
          {
            id: 'les-2-1',
            title: 'Deconstructing Modern Phishing: Reverse Proxies & Modlishka',
            duration: '25 mins',
            content: `Modern attackers do not just copy HTML forms; they run transparent reverse proxies (e.g., Evilginx2) that capture session session tokens in real-time, bypassing traditional 2FA.

How to inspect:
- Always check the Top-Level Domain (TLD) and exact Fully Qualified Domain Name (FQDN).
- Use DNS-over-HTTPS (DoH) with threat blocking (Cloudflare 1.1.1.2 or NextDNS).
- Never trust urgent emails demanding immediate password verification.`,
          }
        ]
      }
    ],
    quiz: {
      id: 'quiz-course-1',
      passingScore: 80,
      questions: [
        {
          id: 'q1',
          question: 'Which method of Two-Factor Authentication provides the highest resistance against real-time phishing attacks?',
          options: [
            { id: 'opt-1', text: 'SMS Text Message Code', isCorrect: false },
            { id: 'opt-2', text: 'Hardware Security Key / FIDO2 Passkey (WebAuthn)', isCorrect: true },
            { id: 'opt-3', text: 'Email Verification Link', isCorrect: false },
            { id: 'opt-4', text: 'Phone Call Automated Voice OTP', isCorrect: false }
          ],
          explanation: 'FIDO2 / WebAuthn cryptographic keys bind authentication tokens to the exact origin domain, making them impossible for reverse-proxy phishing kits to relay.'
        },
        {
          id: 'q2',
          question: 'If you receive an urgent message from your department chairman requesting an immediate money transfer or gift card, what is your first step?',
          options: [
            { id: 'opt-a', text: 'Send the money quickly to avoid academic penalties', isCorrect: false },
            { id: 'opt-b', text: 'Verify via an out-of-band communication channel (e.g. phone call or in-person)', isCorrect: true },
            { id: 'opt-c', text: 'Reply to the email asking for confirmation', isCorrect: false },
            { id: 'opt-d', text: 'Forward the message to your classmates', isCorrect: false }
          ],
          explanation: 'Always verify unexpected requests involving finances or sensitive information through a separate known trusted channel (out-of-band verification).'
        }
      ]
    }
  },
  {
    id: 'course-2',
    slug: 'practical-ctf-foundations',
    title: 'CTF 101: Web Exploitation, Cryptography & OSINT for Beginners',
    description: 'A hands-on, ethical capture-the-flag curriculum covering SQL injection, Burp Suite fundamentals, basic cryptography ciphers, and digital forensics.',
    level: 'Intermediate',
    duration: '4.5 Hours',
    modulesCount: 5,
    enrolledCount: 980,
    rating: 4.95,
    category: 'Offensive & CTF',
    instructor: 'Farhan Kabir Sourav',
    instructorRole: 'Offensive Security Specialist, CSO',
    isPublished: true,
    thumbnail: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80',
    modules: [
      {
        id: 'mod-ctf-1',
        title: 'Module 1: Web Security Fundamentals',
        lessons: [
          {
            id: 'les-ctf-1',
            title: 'HTTP Headers, Burp Suite Interception & Parameter Tampering',
            duration: '35 mins',
            content: 'Understanding how client-side controls can be modified in transit using proxy tools like Burp Suite or OWASP ZAP.',
          }
        ]
      }
    ]
  }
];

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    slug: 'alert-university-stipend-phishing-august-2026',
    title: 'CRITICAL ALERT: Active Phishing Campaign Targeting Bangladeshi University Students',
    banglaTitle: 'জরুরি সতর্কতা: বাংলাদেশি বিশ্ববিদ্যালয় শিক্ষার্থীদের টার্গেট করে ভুয়া উপবৃত্তি ফিশিং ক্যাম্পেইন',
    category: 'Security Alert',
    excerpt: 'An active threat group is spoofing UGC and university registrar domains, promising emergency laptop grants to harvest academic email credentials.',
    content: `### Incident Briefing

Over the past 72 hours, the CSO Cyber Threat Intel team detected a spike in fraudulent emails delivered to students across public and private universities in Bangladesh.

The attackers use domain names such as \`du-portal-grants.live\` and \`ugc-scholarship-bd.com\` to emulate official university portals.

#### Indicators of Compromise (IoCs)
- **Sender Addresses:** \`noreply@university-grants-bd.cc\`, \`admin@ugc-portal-stipend.online\`
- **Malicious Domains:** \`*.ddns.net/portal_auth\`
- **Target Credentials:** Google Workspace SSO, Microsoft 365 student logins.

#### Immediate Recommendations
1. If you entered your password on any unverified portal, immediately perform an account recovery and revoke all active OAuth app permissions.
2. Alert your institutional ICT cell.
3. Submit a ticket to our Cyber Help Center if you require assisted triage.`,
    author: 'Nusrat Jahan Chowdhury',
    authorRole: 'Head of Threat Research',
    publishedAt: '2026-08-14T08:00:00Z',
    readTime: '3 min read',
    isAlert: true,
    tags: ['Phishing', 'University Threat', 'SSO Hijacking', 'IoC'],
    thumbnail: 'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?w=800&auto=format&fit=crop&q=80',
    isPublished: true,
  },
  {
    id: 'art-2',
    slug: 'recovering-compromised-facebook-instagram-guide',
    title: 'The Definitive Guide to Recovering Compromised Social Media Accounts in 2026',
    banglaTitle: 'সোশ্যাল মিডিয়া অ্যাকাউন্ট হ্যাক হলে যা করবেন: সঠিক ও নিরাপদ গাইডলাইন',
    category: 'Incident Response',
    excerpt: 'Step-by-step verified procedures to regain access to hacked Meta, Google, and Telegram accounts without falling for fake "account recovery" scammers.',
    content: `### Beware of Secondary Recovery Scams

When your account is hijacked, **never** pay third-party Instagram or Telegram accounts claiming they can "hack it back" for a fee. 99% of these are advance-fee scammers.

### Official Step-by-Step Response

1. **Meta Account Compromise:**
   - Navigate to the verified endpoint: \`facebook.com/hacked\` or \`instagram.com/hacked\`.
   - Select "Someone else gained access to my account".
   - Use a previously trusted mobile device and Wi-Fi network.
   - If 2FA was locked by attacker, proceed to the Video Selfie Verification flow.

2. **Preserving Evidence:**
   - Take full-screen screenshots of unauthorized emails notifying changes.
   - Note the timestamp and attacker IP/location indicated in the notification.`,
    author: 'Abrar Tanveer Rahman',
    authorRole: 'President & Incident Lead',
    publishedAt: '2026-08-10T12:00:00Z',
    readTime: '6 min read',
    isAlert: false,
    tags: ['Account Recovery', 'Social Media', 'Meta', 'Anti-Scam'],
    thumbnail: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=800&auto=format&fit=crop&q=80',
    isPublished: true,
  },
  {
    id: 'art-3',
    slug: 'sim-swap-mobile-banking-protection',
    title: 'Defending Against SIM-Swap Fraud & Mobile Financial Services (MFS) Thefts',
    banglaTitle: 'সিম সোয়াপ এবং মোবাইল ব্যাংকিং (bKash/Nagad) প্রতারণা থেকে বাঁচার উপায়',
    category: 'Privacy',
    excerpt: 'How attackers spoof identity documents to clone your phone number and intercept mobile banking PINs, and the exact steps to protect yourself.',
    content: `SIM-swapping occurs when a criminal convinces a mobile carrier agent to reassign your phone number to a new SIM card under their control.

### Warning Signs of an Active SIM Swap
- Your phone suddenly displays **"No Service"** or **"Emergency Calls Only"** in an area with good coverage.
- You receive an SMS confirming a SIM replacement request that you did not initiate.

### Immediate Emergency Action
1. Immediately contact your telecom customer care hotline from another phone (Grameenphone 121, Banglalink 121, Robi 121, Teletalk 121) and request an instant emergency SIM suspension.
2. Notify your bank and mobile financial services (bKash 16247, Nagad 16167) to freeze your mobile wallets.`,
    author: 'Shakil Ahmed Khan',
    authorRole: 'Campus Outreach Lead',
    publishedAt: '2026-08-05T09:30:00Z',
    readTime: '5 min read',
    isAlert: false,
    tags: ['MFS', 'bKash', 'SIM Swap', 'Telecommunications'],
    thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=80',
    isPublished: true,
  }
];

export const INITIAL_EVENTS: EventItem[] = [
  {
    id: 'evt-1',
    title: 'CyberShield CTF 2026: Inter-University Ethical Hacking Championship',
    slug: 'cybershield-ctf-2026',
    type: 'CTF',
    date: '2026-09-18',
    time: '10:00 AM - 10:00 PM BST',
    location: 'Hybrid (Online CTFd Platform + Onsite Finals at CSE Department, BUET)',
    isOnline: true,
    meetingLinkOrVenue: 'https://ctf.cybersafestudent.org',
    capacity: 500,
    registeredCount: 384,
    status: 'UPCOMING',
    description: 'A 12-hour jeopardy style CTF competition featuring challenges across Web Exploitation, Reverse Engineering, Cryptography, Forensics, and Threat Intelligence. Exciting prize pool & official certificates.',
    speakers: [
      { name: 'Farhan Kabir Sourav', role: 'CTF Architect', org: 'CSO Offensive Team' },
      { name: 'Dr. Tanvir Alam', role: 'Cybersecurity Advisor', org: 'BUET Cyber Lab' }
    ],
    thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'evt-2',
    title: 'Hands-on Workshop: Social Engineering Defense & Live Phishing Simulation',
    slug: 'social-engineering-workshop-2026',
    type: 'WORKSHOP',
    date: '2026-08-28',
    time: '04:00 PM - 07:00 PM BST',
    location: 'Zoom Interactive Webinar + Hands-on Lab',
    isOnline: true,
    meetingLinkOrVenue: 'Online Conference URL provided after registration',
    capacity: 250,
    registeredCount: 210,
    status: 'UPCOMING',
    description: 'Learn how spear-phishing campaigns are crafted, how reverse proxies bypass 2FA, and practical steps to deploy DNS filtering and hardware security keys on your devices.',
    speakers: [
      { name: 'Nusrat Jahan Chowdhury', role: 'Incident Response Lead', org: 'CSO' },
      { name: 'Abrar Tanveer Rahman', role: 'President', org: 'CSO' }
    ],
    thumbnail: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'evt-3',
    title: 'Campus Cyber Safety Roadshow: DU & NSU Awareness Campaign',
    slug: 'campus-cyber-safety-roadshow',
    type: 'CAMPAIGN',
    date: '2026-07-22',
    time: '11:00 AM - 04:00 PM BST',
    location: 'Dhaka University TSC & NSU Plaza',
    isOnline: false,
    meetingLinkOrVenue: 'TSC Auditorium, University of Dhaka',
    capacity: 600,
    registeredCount: 600,
    status: 'COMPLETED',
    description: 'Over 600 students attended on-site interactive triage booths, received customized account audits, and received emergency cyber safety checklists.',
    speakers: [
      { name: 'Executive Team', role: 'Triage Specialists', org: 'CSO Campus Wing' }
    ],
    thumbnail: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80',
  }
];

export const INITIAL_FAQS: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'Help Requests',
    question: 'Are your incident support services free for students?',
    banglaQuestion: 'শিক্ষার্থীদের জন্য আপনাদের সাইবার সহায়তা কি সম্পূর্ণ বিনামূল্যে?',
    answer: 'Yes, 100% free. The CyberSafe Student Organization is a non-profit student initiative. We never charge money or ask for donations in exchange for incident guidance or technical support.',
    banglaAnswer: 'হ্যাঁ, সম্পূর্ণ ফ্রি। আমাদের সব ধরণের প্রাথমিক পরামর্শ, হেল্প ডেস্ক এবং সচেতনতামূলক প্রশিক্ষণ শিক্ষার্থীদের জন্য ১০০% বিনামূল্যে প্রদান করা হয়।'
  },
  {
    id: 'faq-2',
    category: 'Account Safety',
    question: 'Will a CSO team member ever ask for my password or OTP?',
    banglaQuestion: 'CSO এর কোনো সদস্য কি কখনো আমার পাসওয়ার্ড বা ওটিপি চাইতে পারে?',
    answer: 'STRICTLY NEVER. We have a zero-tolerance policy. No authorized member, support agent, or campus rep will EVER ask for your passwords, OTP codes, recovery keys, or bank PINs. If anyone asks, report them immediately.',
    banglaAnswer: 'কখনোই না! আমাদের কোনো মেম্বার বা প্রতিনিধি কখনোই আপনার পাসওয়ার্ড, ওটিপি, রিকভারি কোড বা ব্যাংক পিন চাইবে না। কেউ চাইলে তাৎক্ষণিক রিপোর্ট করুন।'
  },
  {
    id: 'faq-3',
    category: 'Help Requests',
    question: 'Are you a law-enforcement agency or police unit?',
    banglaQuestion: 'আপনারা কি কোনো সরকারি বা পুলিশ/আইনশৃঙ্খলা বাহিনী?',
    answer: 'No. We are an independent student educational organization providing initial technical triage, threat awareness, and safe guidance. We do not possess police powers. In cases involving blackmail, extortion, or active threats, we guide you to the official Cyber Crime Investigation Division and National Helpline 999.',
    banglaAnswer: 'না। আমরা শিক্ষার্থী পরিচালিত সচেতনতা ও কারিগরি সহায়তা সংগঠন। আইনি ব্যবস্থা বা মামলা করার ক্ষেত্রে আমরা শিক্ষার্থীদের সাইবার ক্রাইম তদন্ত বিভাগ ও থানায় সহায়তার সঠিক নিয়ম জানিয়ে দিই।'
  },
  {
    id: 'faq-4',
    category: 'Member Verification',
    question: 'How do I verify if a person visiting our campus is an authorized CSO representative?',
    banglaQuestion: 'আমাদের ক্যাম্পাসে আসা কোনো ব্যক্তি আসলেই CSO-এর মেম্বার কিনা তা কীভাবে যাচাই করব?',
    answer: 'Ask for their official Member ID card and scan the QR code on the back, or enter their ID (e.g., CSO-BD-000124) into our public verification portal at /verify. Our system checks current live status in real time.',
    banglaAnswer: 'তাদের অফিসিয়াল মেম্বার আইডি কার্ডের কিউআর কোড স্ক্যান করুন অথবা আমাদের ওয়েবসাইটের /verify পেজে মেম্বার আইডি দিয়ে যাচাই করুন।'
  }
];

export const INITIAL_PARTNERS: Partner[] = [
  {
    id: 'part-1',
    name: 'BUET Cyber Security Society',
    type: 'Academic University',
    logoText: 'BUET CYBER',
    description: 'Collaborative technical workshops, CTF problem authoring, and student research mentorship.',
    website: 'https://buet.ac.bd'
  },
  {
    id: 'part-2',
    name: 'DU Information Technology Research Cell',
    type: 'Academic University',
    logoText: 'DU IT CELL',
    description: 'Academic partner for student digital rights research and threat intelligence sharing.',
    website: 'https://du.ac.bd'
  },
  {
    id: 'part-3',
    name: 'National Cyber Security Awareness Coalition',
    type: 'Security NGO',
    logoText: 'NCSAC BD',
    description: 'Nationwide student outreach partner for safe internet campaigns in high schools.',
    website: 'https://cyberaware.org'
  },
  {
    id: 'part-4',
    name: 'Asia-Pacific Student CTF Alliance',
    type: 'Tech Alliance',
    logoText: 'AP-CTF ALLIANCE',
    description: 'Regional offensive security partner for international student cybersecurity tournaments.',
    website: 'https://apctf.net'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    actor: 'Abrar Tanveer Rahman (Super Admin)',
    actorRole: 'SUPER_ADMIN',
    action: 'MEMBER_STATUS_UPDATE',
    resource: 'OrgMember',
    resourceId: 'CSO-BD-000124',
    ipAddress: '103.114.152.18',
    timestamp: '2026-08-15T07:15:00Z',
    details: 'Verified credential renewal for 2026-2027 term.'
  },
  {
    id: 'log-2',
    actor: 'Nusrat Jahan Chowdhury',
    actorRole: 'SUPPORT_AGENT',
    action: 'TICKET_STATUS_CHANGE',
    resource: 'HelpTicket',
    resourceId: 'CSO-HLP-82741',
    ipAddress: '103.205.71.45',
    timestamp: '2026-08-14T11:20:00Z',
    details: 'Changed status to IN_PROGRESS and attached institutional memo.'
  },
  {
    id: 'log-3',
    actor: 'Farhan Kabir Sourav',
    actorRole: 'CONTENT_MANAGER',
    action: 'ARTICLE_PUBLISHED',
    resource: 'Article',
    resourceId: 'art-1',
    ipAddress: '118.179.201.12',
    timestamp: '2026-08-14T08:00:00Z',
    details: 'Published critical security alert regarding university stipend phishing.'
  },
  {
    id: 'log-4',
    actor: 'System Security Engine',
    actorRole: 'SYSTEM',
    action: 'CERTIFICATE_ISSUED',
    resource: 'Certificate',
    resourceId: 'CSO-CERT-2026-8941',
    ipAddress: '127.0.0.1',
    timestamp: '2026-08-12T10:00:00Z',
    details: 'Automated cryptographic signature issued for completed masterclass.'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'High Priority Security Alert',
    message: 'Active phishing campaign targeting university emails detected. Read the official briefing.',
    type: 'SECURITY_ALERT',
    timestamp: '2026-08-14T08:05:00Z',
    isRead: false,
    linkUrl: '/news/alert-university-stipend-phishing-august-2026'
  },
  {
    id: 'notif-2',
    title: 'CyberShield CTF 2026 Registration Open',
    message: 'Spots filling up fast for the Inter-University CTF Championship.',
    type: 'EVENT',
    timestamp: '2026-08-13T12:00:00Z',
    isRead: true,
    linkUrl: '/events/cybershield-ctf-2026'
  },
  {
    id: 'notif-3',
    title: 'Support Ticket CSO-HLP-82741 Updated',
    message: 'Support Agent Nusrat replied with an incident response guidance memo.',
    type: 'TICKET',
    timestamp: '2026-08-14T11:21:00Z',
    isRead: false,
    linkUrl: '/help-center/track?id=CSO-HLP-82741'
  }
];

export const DEMO_USERS: User[] = [
  {
    id: 'user-admin',
    name: 'Abrar Tanveer Rahman',
    email: 'admin@cybersafestudent.org',
    role: 'SUPER_ADMIN',
    institution: 'Department of CSE, BUET',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    createdAt: '2024-01-01T00:00:00Z',
    twoFactorEnabled: true,
  },
  {
    id: 'user-agent',
    name: 'Nusrat Jahan Chowdhury',
    email: 'agent@cybersafestudent.org',
    role: 'SUPPORT_AGENT',
    institution: 'Institute of Information Technology, DU',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    createdAt: '2024-05-10T00:00:00Z',
    twoFactorEnabled: true,
  },
  {
    id: 'user-student',
    name: 'Tanvir Ahmed',
    email: 'student@example.edu',
    role: 'STUDENT',
    institution: 'University of Dhaka',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
    createdAt: '2026-08-01T00:00:00Z',
    twoFactorEnabled: false,
  }
];
