'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  GraduationCap, 
  BookOpen, 
  Sparkles, 
  FileText, 
  Video, 
  Terminal, 
  Search, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  ShieldAlert,
  Flame,
  Star
} from 'lucide-react';
import { useApp } from '@/lib/app-context';

export default function AcademyPage() {
  const { courses, articles } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['ALL', 'Defensive Security', 'Offensive & CTF', 'Phishing & Scams', 'Privacy & Data'];

  const filteredCourses = courses.filter(c => {
    const matchCategory = selectedCategory === 'ALL' || c.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) || c.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchSearch;
  });

  const featuredArticles = articles.slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-mono">
          <GraduationCap className="w-3.5 h-3.5" />
          <span>CYBER DEFENSE & ETHICAL HACKING CURRICULUM</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white">
          Cyber Security Academy
        </h1>
        <p className="text-sm sm:text-base text-slate-300">
          Free, practical, hands-on cybersecurity courses, defensive hygiene guides, and CTF challenges curated specifically for college and university students.
        </p>
      </div>

      {/* Safety Score Diagnostic Hero Banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border border-emerald-500/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-emerald-400 bg-slate-950 px-2.5 py-1 rounded-full border border-emerald-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive Diagnostic</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Evaluate Your Personal Cyber Safety Score
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Answer 10 fast scenarios regarding your password managers, 2FA configurations, social media habits, and phishing discernment to get your Safety Index (0-100) and instant hardening action plan.
          </p>
        </div>
        <Link
          href="/academy/quiz"
          className="shrink-0 px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-md transition flex items-center gap-2"
        >
          <span>Take Safety Assessment →</span>
        </Link>
      </div>

      {/* Search & Category Tabs */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition ${
                selectedCategory === cat 
                  ? 'bg-emerald-500 text-slate-950 font-bold' 
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search courses & topics..."
            className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-400 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>
      </div>

      {/* Courses Grid */}
      <div className="space-y-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-emerald-400" />
          <span>Structured Academy Courses</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map(course => (
            <div 
              key={course.id}
              className="rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between overflow-hidden group"
            >
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 font-semibold">
                    {course.category}
                  </span>
                  <span className="text-slate-400">{course.level}</span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition">
                  <Link href={`/academy/courses/${course.slug}`}>
                    {course.title}
                  </Link>
                </h3>

                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                  {course.description}
                </p>

                <div className="space-y-1 text-xs text-slate-400 font-mono pt-2 border-t border-slate-800">
                  <div className="flex items-center justify-between">
                    <span>Duration: <strong className="text-slate-200">{course.duration}</strong></span>
                    <span>Modules: <strong className="text-slate-200">{course.modulesCount}</strong></span>
                  </div>
                  <div>
                    Instructor: <span className="text-slate-200">{course.instructor}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-1 text-amber-400 text-xs">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span className="font-bold text-white">{course.rating}</span>
                  <span className="text-slate-500">({course.enrolledCount})</span>
                </div>
                <Link
                  href={`/academy/courses/${course.slug}`}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
                >
                  Start Course →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Deep Guides & Threat Articles */}
      <div className="space-y-6 pt-6 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-400" />
            <span>Latest Security Guides & Threat Advisories</span>
          </h2>
          <Link href="/academy/articles" className="text-xs font-semibold text-emerald-400 hover:underline">
            View All Guides →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredArticles.map(art => (
            <div 
              key={art.id}
              className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-emerald-400 font-bold">{art.category}</span>
                  <span className="text-slate-500">{art.readTime}</span>
                </div>
                <h3 className="text-base font-bold text-white hover:text-emerald-300 transition">
                  <Link href={`/academy/articles/${art.slug}`}>
                    {art.title}
                  </Link>
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {art.excerpt}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-500">By {art.author}</span>
                <Link href={`/academy/articles/${art.slug}`} className="text-emerald-400 hover:underline font-medium">
                  Read Guide →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
