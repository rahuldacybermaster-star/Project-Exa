'use client';

import React, { useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { 
  BookOpen, 
  CheckCircle2, 
  Award, 
  ArrowLeft, 
  Play, 
  FileText, 
  Clock, 
  Check, 
  Sparkles,
  ChevronRight,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { CourseLesson } from '@/lib/types';
import confetti from 'canvas-confetti';

export default function CourseDetailPage() {
  const params = useParams();
  const slug = params?.slug as string;

  const { courses, completedLessonIds, completeLesson, issueCertificate, currentUser } = useApp();
  const course = courses.find(c => c.slug === slug) || courses[0];

  const allLessons: CourseLesson[] = course.modules.flatMap(m => m.lessons);
  const [activeLessonId, setActiveLessonId] = useState<string>(allLessons[0]?.id || '');
  const activeLesson = allLessons.find(l => l.id === activeLessonId) || allLessons[0];

  // Quiz state
  const [showQuiz, setShowQuiz] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [issuedCertId, setIssuedCertId] = useState<string | null>(null);

  const isCurrentCompleted = completedLessonIds.includes(activeLesson?.id);

  const handleMarkComplete = (lessonId: string) => {
    completeLesson(lessonId);
  };

  const handleSelectAnswer = (qId: string, optionId: string) => {
    if (quizSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [qId]: optionId }));
  };

  const handleSubmitQuiz = () => {
    if (!course.quiz) return;
    let correctCount = 0;

    course.quiz.questions.forEach(q => {
      const selected = selectedAnswers[q.id];
      const correctOption = q.options.find(o => o.isCorrect);
      if (selected === correctOption?.id) {
        correctCount += 1;
      }
    });

    const percentage = Math.round((correctCount / course.quiz.questions.length) * 100);
    setQuizScore(percentage);
    setQuizSubmitted(true);

    if (percentage >= course.quiz.passingScore) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      // Auto-issue official Certificate
      const certId = issueCertificate({
        recipientName: currentUser?.name || 'Verified Student Learner',
        recipientEmail: currentUser?.email || 'student@university.edu',
        courseOrEventTitle: course.title,
        type: 'COURSE_COMPLETION',
        issueDate: new Date().toISOString().split('T')[0],
        status: 'VALID',
        gradeScore: `${percentage}% Distinction`,
        issuerName: course.instructor,
        issuerDesignation: course.instructorRole,
      });
      setIssuedCertId(certId);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Back button & Breadcrumb */}
      <div className="flex items-center justify-between">
        <Link 
          href="/academy" 
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Courses</span>
        </Link>
        <span className="text-xs font-mono text-emerald-400">
          Level: {course.level} • {course.category}
        </span>
      </div>

      {/* Course Title Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          {course.title}
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
          {course.description}
        </p>
        <div className="pt-2 flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400">
          <span>Instructor: <strong className="text-slate-200">{course.instructor}</strong></span>
          <span>•</span>
          <span>Duration: <strong className="text-slate-200">{course.duration}</strong></span>
          <span>•</span>
          <span>Passing Score: <strong className="text-emerald-400">80%</strong></span>
        </div>
      </div>

      {/* Main Learning Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Active Lesson or Quiz */}
        <div className="lg:col-span-2 space-y-6">
          {!showQuiz ? (
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-semibold">
                    ACTIVE LESSON
                  </span>
                  <h2 className="text-xl font-bold text-white mt-0.5">
                    {activeLesson?.title}
                  </h2>
                </div>
                <span className="text-xs font-mono text-slate-400">
                  Estimated: {activeLesson?.duration}
                </span>
              </div>

              {/* Lesson Rich Content */}
              <div className="prose prose-invert max-w-none text-slate-300 text-xs sm:text-sm leading-relaxed space-y-4 whitespace-pre-line">
                {activeLesson?.content}
              </div>

              {/* Lesson Action Footer */}
              <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <button
                  onClick={() => handleMarkComplete(activeLesson?.id)}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold font-mono transition flex items-center gap-2 ${
                    isCurrentCompleted 
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' 
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>{isCurrentCompleted ? 'Lesson Marked as Completed' : 'Mark Lesson as Completed'}</span>
                </button>

                {course.quiz && (
                  <button
                    onClick={() => setShowQuiz(true)}
                    className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-2"
                  >
                    <Award className="w-4 h-4 text-teal-400" />
                    <span>Proceed to Course Quiz & Certificate →</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Interactive Course Quiz Card */
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-emerald-500/40 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
                    ASSESSMENT & CERTIFICATION QUIZ
                  </span>
                  <h2 className="text-xl font-bold text-white">
                    {course.title} Final Knowledge Check
                  </h2>
                </div>
                <button
                  onClick={() => setShowQuiz(false)}
                  className="text-xs text-slate-400 hover:underline"
                >
                  ← Back to Lesson Notes
                </button>
              </div>

              {/* If Passed & Certificate Issued */}
              {issuedCertId && (
                <div className="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-center space-y-4">
                  <Sparkles className="w-10 h-10 text-emerald-400 mx-auto" />
                  <div className="space-y-1">
                    <h3 className="text-xl font-extrabold text-white">
                      Congratulations! You Passed with {quizScore}%
                    </h3>
                    <p className="text-xs text-slate-300">
                      Your official digital certificate has been cryptographically signed and registered in the CSO verification database.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-emerald-400 font-bold text-sm">
                    Issued Certificate ID: {issuedCertId}
                  </div>
                  <Link
                    href={`/verify/certificate/${issuedCertId}`}
                    className="inline-block px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md transition"
                  >
                    View & Verify Digital Certificate →
                  </Link>
                </div>
              )}

              {/* Questions */}
              {course.quiz && (
                <div className="space-y-6">
                  {course.quiz.questions.map((q, qIndex) => (
                    <div key={q.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                      <div className="text-xs font-mono text-emerald-400 font-semibold">
                        Question {qIndex + 1} of {course.quiz?.questions.length}
                      </div>
                      <h4 className="text-sm font-bold text-white leading-snug">{q.question}</h4>

                      <div className="space-y-2 pt-1">
                        {q.options.map(opt => {
                          const isSelected = selectedAnswers[q.id] === opt.id;
                          return (
                            <button
                              key={opt.id}
                              onClick={() => handleSelectAnswer(q.id, opt.id)}
                              className={`w-full text-left p-3 rounded-xl text-xs transition border flex items-center justify-between ${
                                isSelected 
                                  ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200 font-medium' 
                                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                              }`}
                            >
                              <span>{opt.text}</span>
                              {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
                          <span className="font-bold text-emerald-400">Explanation: </span>
                          <span>{q.explanation}</span>
                        </div>
                      )}
                    </div>
                  ))}

                  {!quizSubmitted ? (
                    <button
                      onClick={handleSubmitQuiz}
                      className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm transition"
                    >
                      Submit Quiz for Evaluation & Certificate →
                    </button>
                  ) : (
                    quizScore !== null && quizScore < 80 && (
                      <div className="p-4 rounded-xl bg-red-950/60 border border-red-500/40 text-center space-y-2 text-xs text-red-200">
                        <div>You scored {quizScore}%. The passing threshold is 80%.</div>
                        <button
                          onClick={() => { setQuizSubmitted(false); setSelectedAnswers({}); }}
                          className="px-4 py-2 rounded-lg bg-slate-800 text-white font-semibold"
                        >
                          Retry Assessment
                        </button>
                      </div>
                    )
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Sidebar: Curriculum Syllabus Navigation */}
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-bold">
              Course Syllabus & Progress
            </h3>

            <div className="space-y-4">
              {course.modules.map((mod, mIndex) => (
                <div key={mod.id} className="space-y-2">
                  <div className="text-xs font-bold text-slate-200 font-mono">
                    {mod.title}
                  </div>
                  <div className="space-y-1.5 pl-2">
                    {mod.lessons.map(lesson => {
                      const isSelected = activeLesson?.id === lesson.id && !showQuiz;
                      const isDone = completedLessonIds.includes(lesson.id);

                      return (
                        <button
                          key={lesson.id}
                          onClick={() => { setActiveLessonId(lesson.id); setShowQuiz(false); }}
                          className={`w-full text-left p-2.5 rounded-xl text-xs transition flex items-center justify-between border ${
                            isSelected 
                              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300 font-semibold' 
                              : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{lesson.title}</span>
                          </div>
                          {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {course.quiz && (
              <div className="pt-3 border-t border-slate-800">
                <button
                  onClick={() => setShowQuiz(true)}
                  className={`w-full p-3 rounded-xl text-xs font-bold font-mono transition flex items-center justify-between border ${
                    showQuiz 
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-300' 
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-emerald-400" />
                    <span>Final Assessment Quiz</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
