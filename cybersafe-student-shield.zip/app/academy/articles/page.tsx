'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  FileText, 
  Search, 
  Clock, 
  User, 
  ArrowRight, 
  ShieldAlert, 
  BookOpen,
  ArrowLeft
} from 'lucide-react';
import { useApp } from '@/lib/app-context';

export default function ArticlesPage() {
  const { articles } = useApp();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');

  const categories = ['ALL', 'Account Recovery', 'Financial Security', 'Threat Advisory', 'Mobile Defense'];

  const filteredArticles = articles.filter(art => {
    const matchCat = selectedCategory === 'ALL' || art.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchSearch = art.title.toLowerCase().includes(search.toLowerCase()) || art.excerpt.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 space-y-12">
      {/* Back button */}
      <Link 
        href="/academy" 
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Academy Hub</span>
      </Link>

      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-mono">
          <FileText className="w-3.5 h-3.5" />
          <span>CYBER DEFENSE REPOSITORIES & PROTOCOLS</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white">
          Security Guides & Threat Bulletins
        </h1>
        <p className="text-sm sm:text-base text-slate-300">
          Field-tested playbooks, triage procedures, and threat intelligence bulletins written by student researchers and ethical hackers.
        </p>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition ${
                selectedCategory === cat
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search guides..."
            className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-400 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArticles.map(art => (
          <div 
            key={art.id}
            className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-4 group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 font-semibold">
                  {art.category}
                </span>
                <span className="text-slate-500">{art.readTime}</span>
              </div>

              <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition leading-snug">
                <Link href={`/academy/articles/${art.slug}`}>
                  {art.title}
                </Link>
              </h3>

              <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                {art.excerpt}
              </p>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs">
              <span className="text-neutral-400 font-mono text-[11px]">{art.publishedAt}</span>
              <Link 
                href={`/academy/articles/${art.slug}`}
                className="text-[#ff3e00] hover:underline font-bold font-mono text-xs flex items-center gap-1 uppercase tracking-wider"
              >
                <span>Read Protocol</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
