'use client';

import React from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { 
  FileText, 
  Clock, 
  User, 
  ArrowLeft, 
  Share2, 
  ShieldAlert, 
  CheckCircle2,
  LifeBuoy
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { CredentialWarningCallout } from '@/components/DisclaimerBanner';

export default function ArticleDetailPage() {
  const params = useParams();
  const slug = params?.slug as string;

  const { articles } = useApp();
  const article = articles.find(a => a.slug === slug) || articles[0];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Back button */}
      <Link 
        href="/academy/articles" 
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to All Security Guides</span>
      </Link>

      {/* Header Card */}
      <div className="p-6 sm:p-10 rounded-lg bg-neutral-900 border border-white/10 space-y-4">
        <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
          <span className="px-2.5 py-0.5 rounded bg-black text-[#ff3e00] border border-[#ff3e00]/30 font-semibold uppercase">
            {article.category}
          </span>
          <span className="text-neutral-400">READ: {article.readTime}</span>
          <span className="text-neutral-600">•</span>
          <span className="text-neutral-400">DATE: {article.publishedAt}</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-display font-black text-white leading-tight uppercase tracking-tight">
          {article.title}
        </h1>

        <div className="flex items-center justify-between pt-4 border-t border-white/10 text-xs text-neutral-400 font-mono">
          <div>
            AUTHOR: <strong className="text-white">{article.author}</strong> ({article.authorRole})
          </div>
          <span className="text-[#ff3e00] font-mono text-[11px] font-bold uppercase">CSO SECURITY BRIEF</span>
        </div>
      </div>

      <CredentialWarningCallout />

      {/* Main Content Body */}
      <div className="p-6 sm:p-10 rounded-3xl bg-slate-900/60 border border-slate-800 prose prose-invert max-w-none text-slate-300 text-xs sm:text-sm leading-relaxed space-y-6 whitespace-pre-line">
        {article.content}
      </div>

      {/* CTA Footer */}
      <div className="p-8 rounded-3xl bg-slate-900 border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-base font-bold text-white">Need Personalized Triage Support?</h3>
          <p className="text-xs text-slate-400">
            If your account is actively compromised and standard steps fail, submit a ticket.
          </p>
        </div>
        <Link
          href="/help-center/submit"
          className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shrink-0 transition"
        >
          Open Confidential Help Ticket →
        </Link>
      </div>
    </div>
  );
}
