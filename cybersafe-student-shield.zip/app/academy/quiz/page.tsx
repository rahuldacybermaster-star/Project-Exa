'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  Sparkles, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  RotateCcw, 
  Lock, 
  ShieldAlert, 
  Award,
  Zap
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import confetti from 'canvas-confetti';

interface Question {
  id: number;
  scenario: string;
  category: string;
  options: {
    text: string;
    points: number; // 0 to 10
    explanation: string;
  }[];
}

const quizQuestions: Question[] = [
  {
    id: 1,
    category: 'Authentication & 2FA',
    scenario: 'How do you secure your primary email (Gmail/Outlook) and social media accounts?',
    options: [
      { text: 'I use App-based TOTP (Google Authenticator / Bitwarden) or Hardware Security Keys.', points: 10, explanation: 'Best practice! App-based TOTP is resilient against SIM-swapping and SMS interception.' },
      { text: 'I use SMS/Text OTP verification on my phone.', points: 6, explanation: 'Better than no 2FA, but vulnerable to SIM-swap fraud and telco interception.' },
      { text: 'I only use a strong password without any 2FA.', points: 2, explanation: 'Risky. If a database is breached or credential-stuffed, attackers have full access.' },
      { text: 'I reuse the same memorable password across multiple accounts.', points: 0, explanation: 'Critical vulnerability. A breach in any low-tier website immediately exposes all your accounts.' },
    ]
  },
  {
    id: 2,
    category: 'Password Hygiene',
    scenario: 'How do you create and remember your passwords for 30+ services?',
    options: [
      { text: 'I use a dedicated open-source/secure password manager (e.g., Bitwarden, 1Password) with unique 16+ char passwords.', points: 10, explanation: 'Optimal security. Password managers ensure zero credential overlap.' },
      { text: 'I use Google Chrome / Apple Keychain built-in generator and manager.', points: 8, explanation: 'Very good! Built-in keychains create high-entropy passwords.' },
      { text: 'I keep a written diary or notes app file with my passwords.', points: 3, explanation: 'Physical notes or unencrypted cloud text files are susceptible to theft or spyware.' },
      { text: 'I memorize 2-3 variations with symbols (e.g. Dhaka@2025).', points: 1, explanation: 'Predictable pattern easily cracked by rule-based dictionary attacks.' },
    ]
  },
  {
    id: 3,
    category: 'Phishing Discernment',
    scenario: 'You receive an urgent WhatsApp message from your classmate asking for a 5-digit WhatsApp registration code they "accidentally sent to your phone". What do you do?',
    options: [
      { text: 'Immediately refuse, call my friend over the phone to verify, and NEVER give the code.', points: 10, explanation: 'Correct! That code is the registration OTP to hijack YOUR own WhatsApp account.' },
      { text: 'Send the code if the profile photo looks genuine.', points: 0, explanation: 'Severe compromise. Attackers hijack accounts and target friends sequentially.' },
      { text: 'Ask them to pay 50 BDT first before sending.', points: 0, explanation: 'Fatal mistake. You lose control of your WhatsApp account completely.' },
    ]
  },
  {
    id: 4,
    category: 'Public Wi-Fi & Campus Networks',
    scenario: 'You connect to free university or cafe Wi-Fi to submit assignments or check bank balances. How do you protect yourself?',
    options: [
      { text: 'I use a trustworthy encrypted VPN or stay on cellular 4G/5G for financial and critical logins.', points: 10, explanation: 'Shields you from Evil Twin rogue access points, ARP poisoning, and unencrypted local eavesdropping.' },
      { text: 'I only browse HTTPS sites and avoid clicking SSL warning bypasses.', points: 7, explanation: 'Decent, but rogue gateways can spoof DNS or present malicious captive portals.' },
      { text: 'I connect freely to any open network without password protection.', points: 0, explanation: 'High risk of Man-in-the-Middle (MitM) session hijacking.' },
    ]
  },
  {
    id: 5,
    category: 'Mobile & Device Safety',
    scenario: 'A friend sends you a link to download a "Modded / Cracked Spotify Premium APK" or game cheat from a Telegram channel. What do you do?',
    options: [
      { text: 'Delete and ignore. Cracked APKs often contain remote access trojans (RATs) and keyloggers.', points: 10, explanation: 'Smart! Sideloaded APKs bypass store security and can read SMS OTPs and photos.' },
      { text: 'Install it, but disable camera permissions.', points: 2, explanation: 'Ineffective. Malicious APKs still abuse accessibility services to steal keystrokes.' },
      { text: 'Install it immediately to save subscription money.', points: 0, explanation: 'Severe compromise vector for student banking and social media tokens.' },
    ]
  },
  {
    id: 6,
    category: 'Social Engineering & MFS Fraud',
    scenario: 'A caller claiming to be a "bKash / Nagad Head Office Manager" says your account will be frozen unless you press *247# or share a 4-digit PIN for verification. How do you respond?',
    options: [
      { text: 'Hang up immediately. Official MFS agents NEVER ask for your secret PIN or OTP over the phone.', points: 10, explanation: 'Golden rule of financial cyber defense.' },
      { text: 'Give the PIN because you fear account closure.', points: 0, explanation: 'Immediate financial theft.' },
      { text: 'Ask them to show their officer badge first.', points: 2, explanation: 'Scammers can send fake digital ID cards over WhatsApp.' },
    ]
  },
  {
    id: 7,
    category: 'Social Media Privacy Hygiene',
    scenario: 'What information is visible to the public or strangers on your Facebook/Instagram profile?',
    options: [
      { text: 'Strictly locked down. My phone number, email, birthdate, and friend list are private (Only Me).', points: 10, explanation: 'Dramatically reduces targeted phishing and social engineering reconnaissance.' },
      { text: 'My friends can see everything, but strangers cannot.', points: 7, explanation: 'Good, though compromised friend accounts can still see your data.' },
      { text: 'My phone number and date of birth are public so classmates can contact me.', points: 1, explanation: 'Used by attackers for password reset triggers and identity cloning.' },
    ]
  },
  {
    id: 8,
    category: 'Session & Device Management',
    scenario: 'You used a library computer or friend\'s laptop to check your email. What was your exit protocol?',
    options: [
      { text: 'Used Incognito, signed out completely, and later verified active sessions from my phone.', points: 10, explanation: 'Prevents session cookie harvesting and browser password auto-saving.' },
      { text: 'Just closed the browser tab without logging out.', points: 1, explanation: 'Session cookies remain active for the next user on the terminal.' },
      { text: 'Checked "Remember this device" for convenience.', points: 0, explanation: 'Leaves your account permanently open to whoever sits at that computer next.' },
    ]
  },
  {
    id: 9,
    category: 'Backup & Recovery Codes',
    scenario: 'Where are your 2FA emergency backup recovery codes (Google/Apple/Bitwarden) stored?',
    options: [
      { text: 'Printed physically in a secure place or kept in an encrypted offline password vault.', points: 10, explanation: 'Ensures you never get locked out even if your phone is lost or damaged.' },
      { text: 'Saved in an email draft or unencrypted phone screenshot.', points: 3, explanation: 'If your email is compromised, attackers get your 2FA bypass keys.' },
      { text: 'I did not save or download backup codes when setting up 2FA.', points: 1, explanation: 'High risk of permanent account lockout if your device breaks.' },
    ]
  },
  {
    id: 10,
    category: 'Emergency Incident Response',
    scenario: 'You notice unexpected login alerts from Russia or Vietnam on your social media account. What is your FIRST action?',
    options: [
      { text: 'Go to Security Settings -> "Log out of all sessions", change master password, and generate new 2FA keys.', points: 10, explanation: 'Instantly invalidates attacker session tokens across all remote devices.' },
      { text: 'Ignore it thinking it is just a network glitch.', points: 0, explanation: 'Allows attackers to change your recovery phone and lock you out.' },
      { text: 'Post a status asking friends if they tried to log in.', points: 2, explanation: 'Wastes critical response minutes while attackers hijack your profile.' },
    ]
  }
];

export default function SafetyQuizPage() {
  const { currentUser } = useApp();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizFinished, setQuizFinished] = useState(false);

  const handleSelectOption = (qId: number, points: number) => {
    setSelectedAnswers(prev => ({ ...prev, [qId]: points }));
    if (currentStep < quizQuestions.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      setQuizFinished(true);
      confetti({ particleCount: 70, spread: 60 });
    }
  };

  const totalPoints = Object.values(selectedAnswers).reduce((a, b) => a + b, 0);
  const totalPossible = quizQuestions.length * 10;
  const scorePercent = Math.round((totalPoints / totalPossible) * 100);

  const getScoreRating = (score: number) => {
    if (score >= 90) return { title: 'Cyber Fortress Sentinel', color: 'text-emerald-400', badge: 'ELITE DEFENDER' };
    if (score >= 70) return { title: 'Cyber Aware Practitioner', color: 'text-teal-300', badge: 'GOOD POSTURE' };
    if (score >= 50) return { title: 'Vulnerable Target', color: 'text-amber-400', badge: 'NEEDS HARDENING' };
    return { title: 'Critical Risk Vector', color: 'text-red-400', badge: 'HIGH RISK' };
  };

  const rating = getScoreRating(scorePercent);

  const resetQuiz = () => {
    setSelectedAnswers({});
    setCurrentStep(0);
    setQuizFinished(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Breadcrumb */}
      <Link 
        href="/academy" 
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
      >
        <span>← Back to Academy Hub</span>
      </Link>

      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>CYBER SAFETY INDEX DIAGNOSTIC</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
          Personal Cyber Safety Score
        </h1>
        <p className="text-xs sm:text-sm text-slate-300">
          Answer 10 fast scenarios to analyze your digital defense posture, discover blind spots, and receive a customized safety blueprint.
        </p>
      </div>

      {!quizFinished ? (
        /* Quiz Active Stepper */
        <div className="p-6 sm:p-10 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
          {/* Progress bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400">
              <span>Question {currentStep + 1} of {quizQuestions.length}</span>
              <span>Category: <strong className="text-emerald-400">{quizQuestions[currentStep].category}</strong></span>
            </div>
            <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
              <div 
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / quizQuestions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Question Scenario */}
          <div className="space-y-3 pt-2">
            <span className="text-xs font-mono uppercase tracking-widest text-slate-500">
              Scenario #{currentStep + 1}
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {quizQuestions[currentStep].scenario}
            </h2>
          </div>

          {/* Options */}
          <div className="space-y-3 pt-2">
            {quizQuestions[currentStep].options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectOption(quizQuestions[currentStep].id, opt.points)}
                className="w-full text-left p-4 rounded-2xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 hover:border-emerald-500/40 text-xs sm:text-sm text-slate-200 transition space-y-1 group"
              >
                <div className="font-semibold group-hover:text-emerald-300 transition">
                  {opt.text}
                </div>
              </button>
            ))}
          </div>

          {/* Navigation Controls */}
          <div className="pt-4 flex items-center justify-between border-t border-slate-800 text-xs">
            {currentStep > 0 ? (
              <button
                onClick={() => setCurrentStep(prev => prev - 1)}
                className="text-slate-400 hover:text-white"
              >
                ← Previous Question
              </button>
            ) : <div></div>}

            <span className="text-slate-500 font-mono">
              Confidential diagnostic • Not stored publicly
            </span>
          </div>
        </div>
      ) : (
        /* Results Card */
        <div className="p-6 sm:p-10 rounded-3xl bg-slate-900 border border-emerald-500/40 shadow-2xl space-y-8">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-400 font-bold">
              {rating.badge}
            </div>

            <div className="space-y-1">
              <div className="text-5xl sm:text-7xl font-extrabold font-mono text-white tracking-tight">
                {scorePercent}<span className="text-emerald-400 text-3xl sm:text-4xl">/100</span>
              </div>
              <h2 className={`text-2xl font-bold ${rating.color}`}>
                {rating.title}
              </h2>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto leading-relaxed">
              {scorePercent >= 80 
                ? 'Excellent work! Your defensive habits are sound. Review the specific recommendations below to remain resilient against zero-day social engineering vectors.'
                : 'Your profile has critical attack surfaces that cybercriminals actively exploit. Implement the priority recommendations below immediately.'
              }
            </p>
          </div>

          {/* Question Breakdown & Insights */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Diagnostic Insights & Recommended Action Steps
            </h3>

            <div className="space-y-3">
              {quizQuestions.map(q => {
                const userScore = selectedAnswers[q.id] || 0;
                const isOptimal = userScore >= 8;

                return (
                  <div 
                    key={q.id}
                    className={`p-4 rounded-2xl border text-xs space-y-2 ${
                      isOptimal 
                        ? 'bg-slate-950/60 border-slate-800' 
                        : 'bg-red-950/20 border-red-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between font-mono">
                      <span className="font-bold text-slate-300">{q.category}</span>
                      <span className={isOptimal ? 'text-emerald-400' : 'text-red-400'}>
                        {userScore}/10 Points
                      </span>
                    </div>
                    <div className="text-slate-300">{q.scenario}</div>
                    <div className="text-slate-400 text-[11px]">
                      <strong className="text-emerald-400">Security Rule: </strong>
                      {q.options[0].explanation}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom actions */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-800">
            <button
              onClick={resetQuiz}
              className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retake Diagnostic</span>
            </button>

            <Link
              href="/academy"
              className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2"
            >
              <span>Enroll in Cyber Defense Course →</span>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
