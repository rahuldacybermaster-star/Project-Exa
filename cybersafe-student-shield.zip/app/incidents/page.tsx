'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  AlertOctagon, 
  ShieldAlert, 
  FileText, 
  CheckCircle2, 
  ExternalLink, 
  PhoneCall, 
  Lock, 
  AlertTriangle,
  Send,
  Upload,
  ArrowRight
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { IncidentCategory } from '@/lib/types';
import { CredentialWarningCallout } from '@/components/DisclaimerBanner';

export default function IncidentsPage() {
  const { submitIncidentReport, incidents } = useApp();

  const [category, setCategory] = useState<IncidentCategory>('PHISHING');
  const [targetPlatform, setTargetPlatform] = useState('Campus WiFi / University Portal');
  const [incidentDate, setIncidentDate] = useState(new Date().toISOString().split('T')[0]);
  const [impactedUrl, setImpactedUrl] = useState('');
  const [threatLevel, setThreatLevel] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'>('HIGH');
  const [description, setDescription] = useState('');
  const [reporterName, setReporterName] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [agreedNoCredentials, setAgreedNoCredentials] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !agreedNoCredentials) return;

    const id = submitIncidentReport({
      reporterName: isAnonymous ? undefined : reporterName,
      reporterEmail: isAnonymous ? undefined : reporterEmail,
      isAnonymous,
      category,
      targetPlatform,
      incidentDate,
      impactedUrlOrAccount: impactedUrl || undefined,
      threatLevel,
      description,
    });

    setSubmittedId(id);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 text-red-300 text-xs font-mono">
          <AlertOctagon className="w-3.5 h-3.5" />
          <span>CYBER THREAT & INCIDENT REPORTING</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white">
          Report a Cyber Threat or Scam
        </h1>
        <p className="text-sm sm:text-base text-slate-300">
          Encountered a phishing website targeting your classmates, an impersonation group, or a malicious app? Report it to our threat intelligence unit for forensic analysis and community alerts.
        </p>
      </div>

      {/* Law Enforcement Advisory Notice */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-amber-500/40 space-y-3 text-xs sm:text-sm text-slate-300">
        <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
          <ShieldAlert className="w-5 h-5" />
          <span>Official Law Enforcement Notice</span>
        </div>
        <p className="leading-relaxed">
          The CyberSafe Student Organization (CSO) preserves Indicators of Compromise (IoCs) and issues awareness bulletins. If you are experiencing direct blackmail, extortion, sexual harassment, or severe financial theft, please also lodge an official General Diary (GD) with your local police station or contact:
        </p>
        <div className="flex flex-wrap items-center gap-3 pt-1 font-mono text-xs">
          <span className="px-3 py-1 rounded bg-slate-950 text-emerald-400 border border-slate-800">
            Police Cyber Crime Division: 01320000888
          </span>
          <span className="px-3 py-1 rounded bg-slate-950 text-white border border-slate-800">
            National Police Emergency: 999
          </span>
        </div>
      </div>

      <CredentialWarningCallout />

      {/* Submission Card or Success State */}
      {submittedId ? (
        <div className="p-8 sm:p-12 rounded-3xl bg-slate-900 border border-emerald-500/40 text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-white">Threat Report Successfully Logged</h2>
            <div className="font-mono text-lg text-emerald-400 font-bold">{submittedId}</div>
            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto">
              Our Threat Research desk has archived the submitted details and Indicators of Compromise. If this threat targets a wider student cohort, a public alert will be published.
            </p>
          </div>

          <div className="pt-4 flex justify-center gap-4">
            <button
              onClick={() => { setSubmittedId(null); setDescription(''); }}
              className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
            >
              Submit Another Report
            </button>
            <Link
              href="/news"
              className="px-6 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-1.5"
            >
              <span>View Live Threat Feed</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <h3 className="text-base font-bold text-white">Incident Threat Specification</h3>
            <button
              type="button"
              onClick={() => setIsAnonymous(!isAnonymous)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold ${
                isAnonymous ? 'bg-purple-950 text-purple-300 border border-purple-500/40' : 'bg-slate-800 text-slate-300'
              }`}
            >
              {isAnonymous ? '✓ Anonymous Reporter' : 'Identified Reporter'}
            </button>
          </div>

          {!isAnonymous && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Your Name / Organization</label>
                <input
                  type="text"
                  value={reporterName}
                  onChange={e => setReporterName(e.target.value)}
                  placeholder="e.g. Department Representative"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-emerald-400"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Email Address</label>
                <input
                  type="email"
                  value={reporterEmail}
                  onChange={e => setReporterEmail(e.target.value)}
                  placeholder="rep@university.edu"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-emerald-400"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Incident Category *</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as IncidentCategory)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-emerald-400 outline-none"
              >
                <option value="PHISHING">Phishing / Credential Harvesting</option>
                <option value="ONLINE_SCAM">MFS Scam / Telegram Fraud</option>
                <option value="FAKE_ACCOUNT">Impersonation / Defamation</option>
                <option value="MALWARE_DEVICE">Malware / Rogue APK / Trojan</option>
                <option value="PRIVACY_MISUSE">Data Leak / Database Breach</option>
                <option value="SUSPICIOUS_WEBSITE">Suspicious University Portal</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Platform / Attack Surface *</label>
              <input
                type="text"
                required
                value={targetPlatform}
                onChange={e => setTargetPlatform(e.target.value)}
                placeholder="e.g. Facebook Messenger, Campus WiFi"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-emerald-400 outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Assessed Threat Level *</label>
              <select
                value={threatLevel}
                onChange={e => setThreatLevel(e.target.value as 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL')}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-emerald-400 outline-none font-bold"
              >
                <option value="LOW">LOW — Isolated spam</option>
                <option value="MEDIUM">MEDIUM — Moderate scam campaign</option>
                <option value="HIGH">HIGH — Active student targeted phishing</option>
                <option value="CRITICAL">CRITICAL — Campus wide compromise</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Impacted Domain URL or Threat Actor Profile</label>
            <input
              type="text"
              value={impactedUrl}
              onChange={e => setImpactedUrl(e.target.value)}
              placeholder="e.g. http://fake-university-login.live or @malicious_scammer_username"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono placeholder:text-slate-500 focus:border-emerald-400 outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Forensic Description & Observed Behavior *</label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe what the threat does, how it spreads, and what indicators you noticed (Never include your passwords)..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
            />
          </div>

          <label className="flex items-start gap-3 cursor-pointer pt-2">
            <input
              type="checkbox"
              required
              checked={agreedNoCredentials}
              onChange={e => setAgreedNoCredentials(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded bg-slate-950 border-slate-700 text-emerald-500"
            />
            <span className="text-xs text-slate-300 leading-relaxed">
              I verify that this report is submitted in good faith for student safety, and that no passwords, OTPs, or private keys are contained herein.
            </span>
          </label>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-red-500 to-amber-500 hover:from-red-400 hover:to-amber-400 text-slate-950 font-bold text-sm shadow-md transition"
          >
            Submit Incident for Threat Analysis →
          </button>
        </form>
      )}

      {/* Recent Incident Feed Preview */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-white">Recently Triaged Threat Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {incidents.map(inc => (
            <div key={inc.id} className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-mono text-emerald-400 font-bold">{inc.id}</span>
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                  {inc.status}
                </span>
              </div>
              <p className="text-slate-300 font-medium">{inc.description}</p>
              <div className="text-[11px] text-slate-400 font-mono">
                Surface: {inc.targetPlatform} • Date: {inc.incidentDate}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
