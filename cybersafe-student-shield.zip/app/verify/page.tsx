'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  CheckCircle2, 
  QrCode, 
  Award, 
  Search, 
  ShieldAlert, 
  UserCheck, 
  ArrowRight, 
  Lock,
  XCircle,
  Clock
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { QRCodeRenderer } from '@/components/QRCodeRenderer';

export default function VerificationHubPage() {
  const { members, certificates } = useApp();
  const [activeTab, setActiveTab] = useState<'member' | 'cert'>('member');
  const [query, setQuery] = useState('');

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-mono">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>OFFICIAL CREDENTIAL REGISTRY</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white">
          Public Member & Certificate Verification
        </h1>
        <p className="text-sm sm:text-base text-slate-300">
          Protecting our community from impersonation. Verify authorized CSO leadership, campus directors, volunteers, and digital achievement certificates in real-time.
        </p>
      </div>

      {/* Main Search Console */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
        <div className="flex items-center justify-center">
          <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-slate-800 gap-1">
            <button
              onClick={() => { setActiveTab('member'); setQuery(''); }}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
                activeTab === 'member' 
                  ? 'bg-emerald-500 text-slate-950 shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>Verify Official Member ID</span>
            </button>

            <button
              onClick={() => { setActiveTab('cert'); setQuery(''); }}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
                activeTab === 'cert' 
                  ? 'bg-emerald-500 text-slate-950 shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Verify Certificate ID</span>
            </button>
          </div>
        </div>

        {/* Input */}
        <div className="max-w-2xl mx-auto space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
              <input
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder={
                  activeTab === 'member'
                    ? 'Enter Member ID (e.g. CSO-BD-000124 or CSO-BD-000099)'
                    : 'Enter Certificate ID (e.g. CSO-CERT-2026-8941)'
                }
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-400 rounded-xl pl-11 pr-4 py-3 text-xs sm:text-sm text-white placeholder:text-slate-500 outline-none font-mono"
              />
            </div>
            <Link
              href={
                query.trim()
                  ? (activeTab === 'member' ? `/verify/member/${query.trim()}` : `/verify/certificate/${query.trim()}`)
                  : '#'
              }
              className={`px-6 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition ${
                query.trim()
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <span>Verify</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400 font-mono pt-1">
            <span className="text-slate-500">Test Sample Records:</span>
            {activeTab === 'member' ? (
              <>
                <button
                  onClick={() => setQuery('CSO-BD-000124')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300"
                >
                  CSO-BD-000124 (Active Lead)
                </button>
                <button
                  onClick={() => setQuery('CSO-BD-000099')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-red-300"
                >
                  CSO-BD-000099 (Revoked Member)
                </button>
                <button
                  onClick={() => setQuery('CSO-BD-000155')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300"
                >
                  CSO-BD-000155 (Expired)
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setQuery('CSO-CERT-2026-8941')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300"
                >
                  CSO-CERT-2026-8941 (Valid Masterclass)
                </button>
                <button
                  onClick={() => setQuery('CSO-CERT-2025-0432')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-red-300"
                >
                  CSO-CERT-2025-0432 (Revoked)
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Explanatory Grid: Anti-Impersonation & QR Verification */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <QrCode className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Dynamic QR Security Model</h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Every physical or digital member ID contains a dynamic QR code that points directly to our server-backed validation endpoint (<code>/verify/member/[ID]</code>).
          </p>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 font-mono space-y-1">
            <div>✓ QR codes NEVER encode permanent validity</div>
            <div>✓ Instant reflection if a member is suspended or revoked</div>
            <div>✓ Zero exposure of sensitive personal information (NID/phone/address)</div>
          </div>
        </div>

        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Privacy by Design</h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Our public verification pages display only organizational designations and validity timestamps. Student national identity numbers, home addresses, personal phone numbers, and private emails remain strictly protected.
          </p>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 font-mono space-y-1">
            <div>✓ Meets International Privacy Standards</div>
            <div>✓ Real-time status lookup against centralized registry</div>
          </div>
        </div>
      </div>
    </div>
  );
}
