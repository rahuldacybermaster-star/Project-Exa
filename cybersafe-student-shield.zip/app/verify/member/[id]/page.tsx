'use client';

import React from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  ShieldCheck, 
  QrCode, 
  ArrowLeft, 
  Building, 
  Calendar, 
  Lock,
  ExternalLink
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { QRCodeRenderer } from '@/components/QRCodeRenderer';
import { MemberStatus } from '@/lib/types';

export default function MemberVerificationPage() {
  const params = useParams();
  const rawId = (params?.id as string) || '';
  const memberId = decodeURIComponent(rawId).trim().toUpperCase();

  const { members } = useApp();
  const member = members.find(m => m.id.toUpperCase() === memberId);

  const verificationUrl = typeof window !== 'undefined' 
    ? window.location.href 
    : `https://cybersafestudent.org/verify/member/${memberId}`;

  const statusBadges: Record<MemberStatus, { bg: string; text: string; icon: React.ReactNode; label: string }> = {
    ACTIVE: {
      bg: 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300',
      text: 'text-emerald-400',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
      label: 'OFFICIAL ACTIVE MEMBER'
    },
    SUSPENDED: {
      bg: 'bg-amber-950/80 border-amber-500/50 text-amber-300',
      text: 'text-amber-400',
      icon: <AlertTriangle className="w-5 h-5 text-amber-400" />,
      label: 'MEMBERSHIP SUSPENDED'
    },
    EXPIRED: {
      bg: 'bg-slate-900 border-slate-700 text-slate-400',
      text: 'text-slate-400',
      icon: <Clock className="w-5 h-5 text-slate-400" />,
      label: 'MEMBERSHIP EXPIRED'
    },
    REVOKED: {
      bg: 'bg-red-950/90 border-red-500/60 text-red-200',
      text: 'text-red-400',
      icon: <XCircle className="w-5 h-5 text-red-400" />,
      label: 'CREDENTIAL REVOKED / TERMINATED'
    },
    PENDING: {
      bg: 'bg-purple-950/80 border-purple-500/50 text-purple-300',
      text: 'text-purple-400',
      icon: <Clock className="w-5 h-5 text-purple-400" />,
      label: 'APPROVAL PENDING'
    },
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Back button */}
      <Link 
        href="/verify" 
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Verification Hub</span>
      </Link>

      {!member ? (
        <div className="p-12 rounded-3xl bg-slate-900 border border-red-500/40 text-center space-y-4">
          <XCircle className="w-12 h-12 text-red-400 mx-auto" />
          <h1 className="text-2xl font-bold text-white">Unrecognized Member ID</h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
            No official record found for <strong className="font-mono text-red-300">{memberId}</strong>.
            The individual presenting this ID is not authorized to represent the CyberSafe Student Organization (CSO).
          </p>
          <div className="pt-2">
            <Link
              href="/verify"
              className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
            >
              Try Another Member ID
            </Link>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Main Verified Card */}
          <div className={`p-6 sm:p-10 rounded-3xl bg-slate-900 border ${
            member.status === 'ACTIVE' 
              ? 'border-emerald-500/40 shadow-2xl shadow-emerald-950/20' 
              : member.status === 'REVOKED'
              ? 'border-red-500/60 shadow-2xl shadow-red-950/20'
              : 'border-slate-800'
          } space-y-8`}>
            
            {/* Status Header Banner */}
            <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-3 ${statusBadges[member.status].bg}`}>
              <div className="flex items-center gap-3">
                {statusBadges[member.status].icon}
                <span className="font-mono font-extrabold tracking-wider text-xs sm:text-sm">
                  {statusBadges[member.status].label}
                </span>
              </div>
              <span className="text-[11px] font-mono opacity-80">
                Verified: {new Date().toLocaleDateString()}
              </span>
            </div>

            {/* If Revoked Warning Box */}
            {member.status === 'REVOKED' && (
              <div className="p-4 rounded-xl bg-red-950/80 border border-red-500/40 text-xs text-red-200 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>REVOCATION NOTICE:</span>
                </div>
                <p>{member.statusReason || 'This individual is no longer affiliated with CSO and has no authority to represent the organization, organize events, or collect information.'}</p>
              </div>
            )}

            {/* Member Profile Block */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
              {/* Photo & Badge */}
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="relative w-36 h-36 rounded-2xl overflow-hidden border-2 border-slate-700 bg-slate-800 shadow-lg">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img 
                    src={member.avatar} 
                    alt={member.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-400 font-semibold">
                  {member.badgeType}
                </span>
              </div>

              {/* Identity Details */}
              <div className="md:col-span-2 space-y-4">
                <div className="space-y-1">
                  <div className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                    Official Member ID: <span className="text-white font-bold">{member.id}</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                    {member.name}
                  </h2>
                  {member.banglaName && (
                    <div className="text-base text-slate-300 font-serif">
                      {member.banglaName}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-slate-500 font-mono block text-[10px]">ORGANIZATIONAL ROLE</span>
                    <span className="font-semibold text-slate-200">{member.role}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-slate-500 font-mono block text-[10px]">DEPARTMENT / WING</span>
                    <span className="font-semibold text-slate-200">{member.department}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-slate-500 font-mono block text-[10px]">ACADEMIC INSTITUTION</span>
                    <span className="font-semibold text-slate-200">{member.institution}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-slate-500 font-mono block text-[10px]">TENURE VALIDITY</span>
                    <span className="font-mono text-slate-200">
                      {member.joinedDate} to {member.validUntil}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Dynamic QR Code Verification Section */}
            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-2 text-center sm:text-left">
                <h4 className="text-sm font-bold text-white flex items-center gap-2 justify-center sm:justify-start">
                  <QrCode className="w-4 h-4 text-emerald-400" />
                  <span>Dynamic Live Verification QR</span>
                </h4>
                <p className="text-xs text-slate-400 max-w-md">
                  Scanning this QR code directs you to this live server endpoint, confirming current validity and preventing credential tampering.
                </p>
                <div className="text-[10px] text-slate-500 font-mono break-all pt-1">
                  Canonical URL: {verificationUrl}
                </div>
              </div>

              <QRCodeRenderer value={verificationUrl} size={140} />
            </div>

            {/* Privacy Protection Callout */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2.5">
              <Lock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p>
                <strong>Privacy by Design:</strong> To protect student safety, personal mobile phone numbers, National Identity (NID) numbers, private email addresses, and residential details are strictly redacted from public verification records.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
