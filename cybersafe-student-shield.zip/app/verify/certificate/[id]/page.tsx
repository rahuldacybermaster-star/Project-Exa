'use client';

import React from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { 
  Award, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  QrCode, 
  ArrowLeft, 
  ShieldCheck, 
  FileCheck,
  Hash
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { QRCodeRenderer } from '@/components/QRCodeRenderer';
import { CertificateStatus } from '@/lib/types';

export default function CertificateVerificationPage() {
  const params = useParams();
  const rawId = (params?.id as string) || '';
  const certId = decodeURIComponent(rawId).trim().toUpperCase();

  const { certificates } = useApp();
  const cert = certificates.find(c => c.id.toUpperCase() === certId);

  const verificationUrl = typeof window !== 'undefined' 
    ? window.location.href 
    : `https://cybersafestudent.org/verify/certificate/${certId}`;

  const statusMap: Record<CertificateStatus, { bg: string; icon: React.ReactNode; label: string }> = {
    VALID: {
      bg: 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
      label: 'AUTHENTIC & VALID CERTIFICATE'
    },
    REVOKED: {
      bg: 'bg-red-950/80 border-red-500/50 text-red-200',
      icon: <XCircle className="w-5 h-5 text-red-400" />,
      label: 'CERTIFICATE REVOKED'
    },
    EXPIRED: {
      bg: 'bg-slate-900 border-slate-700 text-slate-400',
      icon: <Clock className="w-5 h-5 text-slate-400" />,
      label: 'CERTIFICATE EXPIRED'
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Back button */}
      <Link 
        href="/verify" 
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Verification Registry</span>
      </Link>

      {!cert ? (
        <div className="p-12 rounded-3xl bg-slate-900 border border-red-500/40 text-center space-y-4">
          <XCircle className="w-12 h-12 text-red-400 mx-auto" />
          <h1 className="text-2xl font-bold text-white">Certificate Record Not Found</h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
            No official certificate found matching ID <strong className="font-mono text-red-300">{certId}</strong>.
            Please verify the serial number on your credential.
          </p>
          <div className="pt-2">
            <Link
              href="/verify"
              className="px-6 py-2.5 rounded-xl bg-slate-800 text-white text-xs font-semibold"
            >
              Try Another ID
            </Link>
          </div>
        </div>
      ) : (
        <div className="p-6 sm:p-10 rounded-3xl bg-slate-900 border border-emerald-500/40 shadow-2xl space-y-8">
          {/* Status Header */}
          <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-3 ${statusMap[cert.status].bg}`}>
            <div className="flex items-center gap-3">
              {statusMap[cert.status].icon}
              <span className="font-mono font-extrabold tracking-wider text-xs sm:text-sm">
                {statusMap[cert.status].label}
              </span>
            </div>
            <span className="text-[11px] font-mono opacity-80">
              Validated: {new Date().toLocaleDateString()}
            </span>
          </div>

          {/* Certificate Body Card */}
          <div className="p-6 sm:p-8 rounded-2xl bg-slate-950 border border-slate-800 space-y-6 text-center">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Award className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
                OFFICIAL DIGITAL CERTIFICATE OF RECOGNITION
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                {cert.recipientName}
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto pt-1">
                has successfully fulfilled all curriculum requirements, defensive security assessments, and code of ethics for:
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 max-w-xl mx-auto">
              <h3 className="text-base sm:text-lg font-bold text-white text-emerald-300">
                {cert.courseOrEventTitle}
              </h3>
              {cert.gradeScore && (
                <div className="text-xs font-mono text-slate-300 mt-1">
                  Performance Assessment: <span className="font-bold text-white">{cert.gradeScore}</span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-left max-w-xl mx-auto pt-2">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 font-mono block text-[10px]">ISSUE DATE</span>
                <span className="font-mono text-slate-200">{cert.issueDate}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 font-mono block text-[10px]">CREDENTIAL ID</span>
                <span className="font-mono text-emerald-400 font-bold">{cert.id}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 font-mono block text-[10px]">AUTHORIZING BODY</span>
                <span className="font-semibold text-slate-200">CSO Academic Council</span>
              </div>
            </div>

            {/* Issuer Signature Info */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
              <div>
                Authorized by: <strong className="text-slate-200">{cert.issuerName}</strong> ({cert.issuerDesignation})
              </div>
              <div className="font-mono text-[10px] text-slate-500">
                Issued by CyberSafe Student Organization (CSO)
              </div>
            </div>
          </div>

          {/* Cryptographic Hash & QR validation */}
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center sm:text-left">
              <h4 className="text-sm font-bold text-white flex items-center gap-2 justify-center sm:justify-start">
                <Hash className="w-4 h-4 text-emerald-400" />
                <span>Cryptographic Proof & QR Check</span>
              </h4>
              <p className="text-xs text-slate-400 max-w-md">
                This credential is cryptographically anchored. Any visual modification of the student name or certificate text renders the hash invalid.
              </p>
              <div className="p-2 rounded bg-slate-900 text-[10px] text-slate-300 font-mono break-all border border-slate-800">
                Checksum: {cert.hashSignature}
              </div>
            </div>

            <QRCodeRenderer value={verificationUrl} size={140} />
          </div>
        </div>
      )}
    </div>
  );
}
