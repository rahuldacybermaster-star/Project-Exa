'use client';

import React, { useState, useRef, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { 
  MessageSquare, 
  Send, 
  Paperclip, 
  Lock, 
  ShieldCheck, 
  User, 
  Bot, 
  CheckCheck, 
  Clock, 
  AlertTriangle,
  ArrowLeft,
  LifeBuoy
} from 'lucide-react';
import Link from 'next/link';
import { useApp } from '@/lib/app-context';

function LiveChatContent() {
  const searchParams = useSearchParams();
  const linkedTicket = searchParams.get('ticket') || '';

  const { chats, activeChat, setActiveChat, sendLiveChatMessage, startOrGetChat, currentUser } = useApp();
  const [inputMsg, setInputMsg] = useState('');
  const [studentNameInput, setStudentNameInput] = useState(currentUser?.name || '');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentChat = activeChat || (chats.length > 0 ? chats[0] : null);

  useEffect(() => {
    if (!activeChat && chats.length > 0) {
      setActiveChat(chats[0]);
    }
  }, [chats, activeChat, setActiveChat]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentChat?.messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim() || !currentChat) return;

    const isAgentRole = currentUser?.role !== 'STUDENT' && currentUser?.role !== 'GUEST';
    sendLiveChatMessage(currentChat.id, inputMsg.trim(), isAgentRole ? 'agent' : 'student');
    setInputMsg('');

    if (!isAgentRole) {
      setIsTyping(true);
      setTimeout(() => setIsTyping(false), 1400);
    }
  };

  const handleStartNewSession = () => {
    const name = studentNameInput.trim() || 'Student Requester';
    const newChat = startOrGetChat(name, currentUser?.email, linkedTicket || undefined);
    setActiveChat(newChat);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="text-xs font-mono text-emerald-400 font-bold uppercase">
              CSO LIVE RESPONSE DESK • ONLINE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Real-Time Cyber Triage Chat
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/help-center"
            className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:text-white"
          >
            Help Center
          </Link>
          <Link
            href="/help-center/submit"
            className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs"
          >
            Submit Formal Ticket
          </Link>
        </div>
      </div>

      {/* Security Warning Callout */}
      <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/30 text-xs text-slate-200 flex items-center gap-3">
        <Lock className="w-4 h-4 text-red-400 shrink-0" />
        <span>
          <strong className="text-red-300 font-semibold">ZERO CREDENTIAL PROTOCOL:</strong> Never type your password, 2FA code, recovery key, or banking PIN in live chat. Our agents will NEVER ask for secrets.
        </span>
      </div>

      {/* Chat Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[620px]">
        {/* Left Sidebar: Conversations list & session start */}
        <div className="lg:col-span-1 rounded-3xl bg-slate-900 border border-slate-800 p-4 flex flex-col justify-between overflow-hidden">
          <div className="space-y-4 overflow-y-auto">
            <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-bold">
              Active Sessions
            </h3>

            <div className="space-y-2">
              {chats.map(chat => {
                const isSelected = currentChat?.id === chat.id;
                return (
                  <button
                    key={chat.id}
                    onClick={() => setActiveChat(chat)}
                    className={`w-full text-left p-3 rounded-2xl border transition ${
                      isSelected 
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-white' 
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-semibold mb-1">
                      <span className="truncate">{chat.studentName}</span>
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate">{chat.lastMessage}</p>
                    {chat.ticketId && (
                      <span className="mt-1 inline-block text-[10px] font-mono text-emerald-400 bg-slate-900 px-1.5 py-0.2 rounded">
                        {chat.ticketId}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 space-y-2">
            <div className="text-[11px] text-slate-400 font-mono">Start New Session:</div>
            <input
              type="text"
              value={studentNameInput}
              onChange={e => setStudentNameInput(e.target.value)}
              placeholder="Your Name / Student ID"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 outline-none"
            />
            <button
              onClick={handleStartNewSession}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 text-xs font-semibold border border-slate-700 transition"
            >
              + Launch New Triage Room
            </button>
          </div>
        </div>

        {/* Right Main Chat Window */}
        <div className="lg:col-span-3 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between overflow-hidden">
          {/* Chat Window Header */}
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold font-mono">
                CSO
              </div>
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>{currentChat?.studentName || 'Student Incident Room'}</span>
                  {currentChat?.ticketId && (
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                      Linked Ticket: {currentChat.ticketId}
                    </span>
                  )}
                </h4>
                <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>Agent Online: {currentChat?.assignedAgentName || 'Nusrat Jahan Chowdhury (Incident Response Lead)'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {currentChat?.messages.map((msg) => {
              const isMe = msg.senderType === (currentUser?.role === 'STUDENT' ? 'student' : 'agent');
              const isSystem = msg.senderType === 'system';

              if (isSystem) {
                return (
                  <div key={msg.id} className="text-center my-3">
                    <span className="inline-block px-3 py-1.5 rounded-full bg-slate-950 border border-slate-800 text-[11px] text-slate-400 font-mono">
                      {msg.message}
                    </span>
                  </div>
                );
              }

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mb-1">
                    <span>{msg.senderName}</span>
                    <span>•</span>
                    <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <div
                    className={`max-w-lg p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                      isMe 
                        ? 'bg-emerald-600 text-slate-950 font-medium rounded-tr-none' 
                        : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.message}</p>
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.4s]"></div>
                <span>Support agent is typing response...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input Box */}
          <form onSubmit={handleSendMessage} className="p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              required
              value={inputMsg}
              onChange={e => setInputMsg(e.target.value)}
              placeholder="Ask an incident question or provide an update... (DO NOT share passwords)"
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none font-sans"
            />
            <button
              type="submit"
              className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Send</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function LiveChatPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading Live Chat...</div>}>
      <LiveChatContent />
    </Suspense>
  );
}
