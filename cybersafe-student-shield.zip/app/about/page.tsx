'use client';

import React from 'react';
import Link from 'next/link';
import { 
  ShieldCheck, 
  Target, 
  Eye, 
  Users, 
  Lock, 
  AlertTriangle, 
  CheckCircle, 
  GraduationCap, 
  PhoneCall,
  ArrowRight
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';

export default function AboutPage() {
  const { lang, t } = useI18n();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
          ABOUT CYBERSAFE STUDENT ORGANIZATION (CSO)
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          {lang === 'bn' ? 'আমরা কারা ও আমাদের লক্ষ্য' : 'Who We Are & What Drives Us'}
        </h1>
        <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
          {lang === 'bn' 
            ? 'শিক্ষার্থীদের সাইবার স্পেসে নিরাপদ রাখা, ডিজিটাল সচেতনতা বাড়ানো এবং বিপদে প্রাথমিক কারিগরি ও মানসিক দিকনির্দেশনা দেওয়ার জন্য গঠিত একটি অলাভজনক প্ল্যাটফর্ম।'
            : 'A dedicated student-led initiative delivering confidential cyber incident guidance, defensive hygiene training, and verifiable community standards across academic institutions.'}
        </p>
      </div>

      {/* Mission & Vision Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Target className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-white">Our Mission (আমাদের লক্ষ্য)</h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            To empower every high school, college, and university student with practical cyber hygiene skills, protect victims of account hijackings and online harassment through compassionate technical triage, and establish a national network of trained student defenders.
          </p>
          <ul className="space-y-2 text-xs text-slate-400 font-mono pt-2">
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Democratize ethical hacking and defensive education</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Provide confidential, 100% free incident triage</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Guide students safely toward official law enforcement channels</span>
            </li>
          </ul>
        </div>

        <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-teal-950/80 border border-teal-500/30 flex items-center justify-center text-teal-400">
            <Eye className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-white">Our Vision (আমাদের ভিশন)</h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            A resilient student cyberspace free from predatory scams, blackmail, and unmitigated phishing, where young minds innovate fearlessly and serve as digital ambassadors for their campuses and communities.
          </p>
          <ul className="space-y-2 text-xs text-slate-400 font-mono pt-2">
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-teal-400" />
              <span>A verified student representative in every campus</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-teal-400" />
              <span>Zero credentials compromised through awareness drives</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-teal-400" />
              <span>Open-source educational curricula accessible to all</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Strict Organizational Scope Disclaimer */}
      <div className="p-6 sm:p-8 rounded-3xl bg-amber-950/20 border border-amber-500/30 space-y-4">
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
          <h3 className="text-lg sm:text-xl font-bold text-amber-300">
            Crucial Organizational Scope & Legal Boundaries
          </h3>
        </div>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          The CyberSafe Student Organization (CSO) is <strong>NOT a law-enforcement agency, police department, or forensic investigator</strong>.
          We provide initial educational support, safety checklist guidance, and technical best practices. We do NOT:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            ❌ We never conduct unauthorized offensive hacking or surveillance.
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            ❌ We do not guarantee recovery of deleted accounts or stolen funds.
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            ❌ We never ask for passwords, OTPs, or private encryption keys.
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            ✓ We provide official referral templates for Police Cyber Units.
          </div>
        </div>
      </div>

      {/* Core Principles */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-white text-center">Core Ethical Principles</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="text-emerald-400 font-mono text-xs font-bold uppercase">01. Privacy & Dignity</div>
            <h4 className="text-base font-bold text-white">Confidential Triage</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every student incident is treated with absolute confidentiality. Anonymous ticket submission is supported by default.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="text-emerald-400 font-mono text-xs font-bold uppercase">02. Zero Profit / Zero Fees</div>
            <h4 className="text-base font-bold text-white">100% Free for Students</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              We never charge fees or accept financial compensation for support, triage, or community certifications.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="text-emerald-400 font-mono text-xs font-bold uppercase">03. Public Verification</div>
            <h4 className="text-base font-bold text-white">Anti-Impersonation Check</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every official member and certificate is cryptographically verifiable online via unique IDs and dynamic QR codes.
            </p>
          </div>
        </div>
      </div>

      {/* Call to Actions */}
      <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-lg font-bold text-white">Interested in joining our mission?</h3>
          <p className="text-xs text-slate-400">Apply to become a campus representative or join our incident response team.</p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/apply/volunteer"
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition"
          >
            Apply as Volunteer
          </Link>
          <Link
            href="/team"
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition"
          >
            Meet the Team
          </Link>
        </div>
      </div>
    </div>
  );
}
