import type { Metadata } from 'next';
import './globals.css';
import { I18nProvider } from '@/lib/i18n';
import { AppProvider } from '@/lib/app-context';
import { Navbar } from '@/components/Navbar';
import { DisclaimerBanner } from '@/components/DisclaimerBanner';
import { Footer } from '@/components/Footer';

export const metadata: Metadata = {
  title: 'CyberSafe Student Organization (CSO) | Cyber Education, Help & Verification',
  description: 'A student-focused cybersecurity awareness, incident triage, CTF training, and official member verification organization.',
  openGraph: {
    title: 'CyberSafe Student Organization (CSO)',
    description: 'Student-focused cyber safety education, incident assistance, and member verification.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CyberSafe Student Organization (CSO)',
    description: 'Student-focused cyber safety education, incident assistance, and member verification.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-slate-950 text-slate-100 min-h-screen flex flex-col antialiased selection:bg-[#ff3e00]/30 selection:text-white">
        <I18nProvider>
          <AppProvider>
            <Navbar />
            <main className="flex-1">
              {children}
            </main>
            <Footer />
          </AppProvider>
        </I18nProvider>
      </body>
    </html>
  );
}
