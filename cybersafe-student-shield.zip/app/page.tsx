'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { 
  Shield, 
  LifeBuoy, 
  GraduationCap, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  QrCode, 
  Activity, 
  Lock, 
  Users, 
  Award, 
  FileSearch, 
  Terminal, 
  Sparkles,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  Flame
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useApp } from '@/lib/app-context';
import { CredentialWarningCallout } from '@/components/DisclaimerBanner';

export default function HomePage() {
  const { t } = useI18n();
  const { members, courses, articles, events, tickets } = useApp();
  const [quickVerifyInput, setQuickVerifyInput] = useState('');
  const [verifyType, setVerifyType] = useState<'member' | 'cert'>('member');

  const alerts = articles.filter(a => a.isAlert);
  const featuredCourses = courses.slice(0, 2);
  const upcomingEvents = events.slice(0, 2);

  return (
    <div className="space-y-16 lg:space-y-24 pb-20">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-10 pb-16 lg:pt-16 lg:pb-24 border-b border-slate-800/80 bg-radial from-slate-900/80 via-slate-950 to-slate-950">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto space-y-6">
            {/* Top Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-mono tracking-wide">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>{t('hero.badge')}</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15]">
              {t('hero.title')}
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
              {t('hero.subtitle')}
            </p>

            {/* Credential Reminder Banner in Hero */}
            <div className="max-w-2xl mx-auto pt-2">
              <div className="p-3 rounded-xl bg-slate-900/90 border border-emerald-500/30 text-xs text-slate-300 flex items-center justify-center gap-2">
                <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong className="text-emerald-300">Privacy-First Triage:</strong> 100% Free for students. Zero passwords, OTPs, or fees will ever be requested.
                </span>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Link
                href="/help-center/submit"
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm sm:text-base shadow-lg shadow-emerald-500/20 transition flex items-center gap-2"
              >
                <LifeBuoy className="w-5 h-5" />
                <span>{t('hero.cta_help')}</span>
              </Link>

              <Link
                href="/academy"
                className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-100 border border-slate-700 font-semibold text-sm sm:text-base transition flex items-center gap-2"
              >
                <GraduationCap className="w-5 h-5 text-emerald-400" />
                <span>{t('hero.cta_learn')}</span>
              </Link>

              <Link
                href="/verify"
                className="px-6 py-3.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 font-semibold text-sm sm:text-base transition flex items-center gap-2"
              >
                <QrCode className="w-5 h-5 text-emerald-400" />
                <span>{t('hero.cta_verify')}</span>
              </Link>
            </div>
          </div>

          {/* Quick Verification Search Console Widget */}
          <div className="mt-12 max-w-3xl mx-auto">
            <div className="p-4 sm:p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl backdrop-blur-xl">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white tracking-wide uppercase font-mono">
                    Instant Member & Certificate Verification
                  </h3>
                </div>
                <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                  <button
                    onClick={() => setVerifyType('member')}
                    className={`px-3 py-1 rounded-lg transition font-medium ${
                      verifyType === 'member' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Member ID
                  </button>
                  <button
                    onClick={() => setVerifyType('cert')}
                    className={`px-3 py-1 rounded-lg transition font-medium ${
                      verifyType === 'cert' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Certificate ID
                  </button>
                </div>
              </div>

              <div className="mt-4 flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={quickVerifyInput}
                  onChange={(e) => setQuickVerifyInput(e.target.value)}
                  placeholder={verifyType === 'member' ? 'e.g. CSO-BD-000124 (or try CSO-BD-000099)' : 'e.g. CSO-CERT-2026-8941'}
                  className="flex-1 bg-slate-950 border border-slate-700 focus:border-emerald-400 px-4 py-2.5 rounded-xl text-sm text-white placeholder:text-slate-500 outline-none font-mono"
                />
                <Link
                  href={quickVerifyInput ? (verifyType === 'member' ? `/verify/member/${quickVerifyInput.trim()}` : `/verify/certificate/${quickVerifyInput.trim()}`) : '/verify'}
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition flex items-center justify-center gap-2"
                >
                  <span>Verify Record</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-400 font-mono">
                <span className="text-slate-500">Quick Test IDs:</span>
                <button
                  onClick={() => { setVerifyType('member'); setQuickVerifyInput('CSO-BD-000124'); }}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300"
                >
                  CSO-BD-000124 (Active)
                </button>
                <button
                  onClick={() => { setVerifyType('member'); setQuickVerifyInput('CSO-BD-000099'); }}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-red-300"
                >
                  CSO-BD-000099 (Revoked)
                </button>
                <button
                  onClick={() => { setVerifyType('cert'); setQuickVerifyInput('CSO-CERT-2026-8941'); }}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-teal-300"
                >
                  CSO-CERT-2026-8941
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. LIVE SECURITY ALERTS / THREAT INTELLIGENCE FEED */}
      {alerts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/40 via-slate-900 to-amber-950/20 border border-red-500/40 shadow-lg">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-red-900/60 text-red-400 shrink-0">
                  <Flame className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-red-400 bg-red-950 px-2 py-0.5 rounded border border-red-500/30">
                      THREAT INTELLIGENCE ADVISORY
                    </span>
                    <span className="text-xs text-slate-400 font-mono">Aug 2026</span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-white mt-1">
                    {alerts[0].title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5 line-clamp-2">
                    {alerts[0].excerpt}
                  </p>
                </div>
              </div>
              <Link
                href={`/news/${alerts[0].slug}`}
                className="shrink-0 px-4 py-2 rounded-xl bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-500/40 text-xs font-semibold flex items-center gap-1.5 transition"
              >
                <span>Read Full Advisory & IoCs</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* 3. IMPACT STATS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
            <div className="text-2xl sm:text-4xl font-extrabold text-white font-mono">1,400+</div>
            <div className="text-xs text-slate-400 font-medium">{t('stats.students')}</div>
          </div>
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
            <div className="text-2xl sm:text-4xl font-extrabold text-emerald-400 font-mono">180+</div>
            <div className="text-xs text-slate-400 font-medium">{t('stats.cases')}</div>
          </div>
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
            <div className="text-2xl sm:text-4xl font-extrabold text-teal-400 font-mono">24 Min</div>
            <div className="text-xs text-slate-400 font-medium">{t('stats.response_time')}</div>
          </div>
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
            <div className="text-2xl sm:text-4xl font-extrabold text-white font-mono">100%</div>
            <div className="text-xs text-slate-400 font-medium">Free & Zero Credential Policy</div>
          </div>
        </div>
      </section>

      {/* 4. WHAT WE DO: 4 PILLARS OF STUDENT PROTECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
            CORE CAPABILITIES
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            How CyberSafe Student Shield Serves You
          </h2>
          <p className="text-sm text-slate-400">
            A complete defensive and educational ecosystem designed for university and college students.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Pillar 1: Help & Incident Triage */}
          <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-emerald-500/40 transition group space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <LifeBuoy className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition">
              Incident Triage & Support
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Step-by-step guidance for hacked accounts, credential exposure, phishing attacks, and online harassment with unique tracking IDs.
            </p>
            <Link 
              href="/help-center" 
              className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold hover:underline"
            >
              Open Help Desk <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Pillar 2: Academy & CTF */}
          <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-teal-500/40 transition group space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-950/80 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <Terminal className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-teal-300 transition">
              Hands-On CTFs & Academy
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Practical modules on password managers, WebAuthn passkeys, web exploit mitigation, and ethical hacking competitions.
            </p>
            <Link 
              href="/academy" 
              className="inline-flex items-center gap-1.5 text-xs text-teal-400 font-semibold hover:underline"
            >
              Explore Academy <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Pillar 3: Official Verification */}
          <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-cyan-500/40 transition group space-y-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition">
              Public Member Verification
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Live cryptographic verification of authorized campus directors, trainers, and certificates to prevent impersonation fraud.
            </p>
            <Link 
              href="/verify" 
              className="inline-flex items-center gap-1.5 text-xs text-cyan-400 font-semibold hover:underline"
            >
              Verify Credentials <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Pillar 4: Campus Network */}
          <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-purple-500/40 transition group space-y-4">
            <div className="w-12 h-12 rounded-xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition">
              Campus Representatives
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Student ambassadors leading digital safety workshops and awareness drives across universities throughout the country.
            </p>
            <Link 
              href="/apply/campus-rep" 
              className="inline-flex items-center gap-1.5 text-xs text-purple-400 font-semibold hover:underline"
            >
              Become a Campus Rep <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>

      {/* 5. INTERACTIVE CYBER SAFETY SCORE QUIZ BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/40 border border-emerald-500/30 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-2 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-mono">
                <Sparkles className="w-3.5 h-3.5" />
                <span>INTERACTIVE DIAGNOSTIC</span>
              </div>
              <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
                What is your Cyber Safety Score?
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                Take our 3-minute student assessment covering 2FA habits, phishing discernment, password hygiene, and device encryption to get an instant safety rating (0-100) and customized hardening checklist.
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <Link
                  href="/academy/quiz"
                  className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-md transition"
                >
                  Start Safety Assessment →
                </Link>
                <span className="text-xs text-slate-400 font-mono">
                  ✓ Instant Score • No login required
                </span>
              </div>
            </div>

            {/* Score Preview Visual */}
            <div className="flex justify-center">
              <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-full border-4 border-emerald-500/30 bg-slate-950 flex flex-col items-center justify-center p-4 text-center shadow-inner relative">
                <div className="absolute inset-2 rounded-full border border-dashed border-emerald-500/20 animate-spin-slow"></div>
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400">Target Score</span>
                <span className="text-4xl sm:text-5xl font-extrabold text-emerald-400 font-mono my-1">95+</span>
                <span className="text-[11px] text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Hardened Tier
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. FEATURED ACADEMY COURSES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
              ACADEMY HIGHLIGHTS
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Featured Security Courses
            </h2>
          </div>
          <Link 
            href="/academy" 
            className="text-xs sm:text-sm font-semibold text-emerald-400 hover:underline flex items-center gap-1"
          >
            View all courses & guides →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {featuredCourses.map((course) => (
            <div 
              key={course.id}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 overflow-hidden hover:border-slate-700 transition flex flex-col justify-between"
            >
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                    {course.category}
                  </span>
                  <span className="text-slate-400">{course.duration} • {course.level}</span>
                </div>
                <h3 className="text-xl font-bold text-white hover:text-emerald-300 transition">
                  <Link href={`/academy/courses/${course.slug}`}>
                    {course.title}
                  </Link>
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 line-clamp-2 leading-relaxed">
                  {course.description}
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-400 font-mono pt-2">
                  <span>Instructor: <strong className="text-slate-200">{course.instructor}</strong></span>
                  <span>•</span>
                  <span>{course.enrolledCount} enrolled</span>
                </div>
              </div>

              <div className="p-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs text-emerald-400 font-medium">Free Student Certification Included</span>
                <Link
                  href={`/academy/courses/${course.slug}`}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
                >
                  Start Course →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. UPCOMING EVENTS & CTF */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
              COMMUNITY COMPETITIONS
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Upcoming CTFs & Workshops
            </h2>
          </div>
          <Link 
            href="/events" 
            className="text-xs sm:text-sm font-semibold text-emerald-400 hover:underline flex items-center gap-1"
          >
            View all tournaments →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {upcomingEvents.map((event) => (
            <div 
              key={event.id}
              className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4 hover:border-slate-700 transition"
            >
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="px-2.5 py-1 rounded bg-teal-950 text-teal-300 border border-teal-500/30 font-bold">
                  {event.type}
                </span>
                <span className="text-slate-400">{event.date}</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                <Link href={`/events/${event.slug}`} className="hover:text-emerald-300 transition">
                  {event.title}
                </Link>
              </h3>
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {event.description}
              </p>
              <div className="text-xs font-mono text-slate-400 space-y-1 pt-1">
                <div>Venue: <span className="text-slate-200">{event.location}</span></div>
                <div>Capacity: <span className="text-emerald-400">{event.registeredCount} / {event.capacity} registered</span></div>
              </div>
              <div className="pt-2 flex items-center justify-between">
                <Link
                  href={`/events/${event.slug}`}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition"
                >
                  Register Free Seat →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. ACADEMIC & NGO PARTNERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
          AFFILIATIONS & INSTITUTIONAL PARTNERS
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 font-mono text-xs font-bold text-slate-300 flex items-center justify-center">
            BUET CYBER LAB
          </div>
          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 font-mono text-xs font-bold text-slate-300 flex items-center justify-center">
            DU IT RESEARCH CELL
          </div>
          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 font-mono text-xs font-bold text-slate-300 flex items-center justify-center">
            NCSAC BANGLADESH
          </div>
          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 font-mono text-xs font-bold text-slate-300 flex items-center justify-center">
            ASIA PACIFIC CTF LEAGUE
          </div>
        </div>
      </section>

      {/* 9. FINAL ACTION CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-slate-900 border border-slate-800 text-center space-y-6">
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
            Facing a Cyber Incident or Seeking Guidance?
          </h2>
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Submit a confidential support ticket or talk with a verified student responder in our secure live chat right now.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link
              href="/help-center/submit"
              className="px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition flex items-center gap-2"
            >
              <LifeBuoy className="w-4 h-4" />
              <span>Submit Help Ticket</span>
            </Link>
            <Link
              href="/chat"
              className="px-6 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm border border-slate-700 transition"
            >
              Open Live Support Chat
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
