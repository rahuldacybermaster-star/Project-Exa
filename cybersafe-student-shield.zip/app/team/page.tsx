'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useApp } from '@/lib/app-context';
import { CheckCircle2, Shield, QrCode, ExternalLink } from 'lucide-react';

export default function TeamPage() {
  const { members } = useApp();

  const coreTeam = members.filter(m => m.status === 'ACTIVE');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
          ORGANIZATIONAL LEADERSHIP & MENTORS
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white">
          Meet the Defenders
        </h1>
        <p className="text-sm sm:text-base text-slate-300">
          Student leaders, researchers, and campus directors leading cybersecurity education and defensive triage. Every official member possesses a verifiable CSO ID.
        </p>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {coreTeam.map((member) => (
          <div 
            key={member.id}
            className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden flex flex-col justify-between hover:border-emerald-500/40 transition group"
          >
            <div className="relative h-56 w-full bg-slate-800">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img 
                src={member.avatar} 
                alt={member.name} 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition duration-300"
              />
              <div className="absolute top-3 right-3 px-2 py-1 rounded-full bg-emerald-950/90 border border-emerald-500/40 text-emerald-400 text-[10px] font-mono font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>VERIFIED</span>
              </div>
            </div>

            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div className="space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-semibold">
                  {member.badgeType}
                </span>
                <h3 className="text-base font-bold text-white group-hover:text-emerald-300 transition">
                  {member.name}
                </h3>
                {member.banglaName && (
                  <div className="text-xs text-slate-400 font-serif">
                    {member.banglaName}
                  </div>
                )}
                <p className="text-xs text-slate-300 font-medium pt-1">
                  {member.role}
                </p>
                <p className="text-[11px] text-slate-400">
                  {member.institution}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">{member.id}</span>
                <Link
                  href={`/verify/member/${member.id}`}
                  className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-mono font-medium"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Verify ID</span>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Advisory & Mentorship Note */}
      <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-xl font-bold text-white">Faculty Advisors & Industry Mentors</h3>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          Our curriculum, ethical guidelines, and threat intelligence triage procedures are periodically reviewed in consultation with university cybersecurity faculty from BUET, DU, NSU, and certified industry ethical hackers.
        </p>
      </div>
    </div>
  );
}
