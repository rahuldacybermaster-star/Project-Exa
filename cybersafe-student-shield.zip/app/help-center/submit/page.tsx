'use client';

import React, { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  LifeBuoy, 
  AlertTriangle, 
  Upload, 
  ShieldCheck, 
  CheckCircle2, 
  Lock, 
  ArrowLeft, 
  FileText,
  Trash2
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { IncidentCategory, TicketPriority } from '@/lib/types';
import { CredentialWarningCallout } from '@/components/DisclaimerBanner';

function HelpRequestForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialCategory = (searchParams.get('category') as IncidentCategory) || 'ACCOUNT_HACKING';

  const { submitHelpTicket, currentUser } = useApp();

  const [isAnonymous, setIsAnonymous] = useState(false);
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState<IncidentCategory>(initialCategory);
  const [platformInvolved, setPlatformInvolved] = useState('Facebook & Messenger');
  const [incidentDate, setIncidentDate] = useState(new Date().toISOString().split('T')[0]);
  const [severity, setSeverity] = useState<TicketPriority>('HIGH');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [files, setFiles] = useState<{ name: string; size: string; type: string }[]>([]);
  const [agreedNoCredentials, setAgreedNoCredentials] = useState(false);
  const [agreedScope, setAgreedScope] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSimulatedFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const f = e.target.files[0];
      const sizeFormatted = `${Math.round(f.size / 1024)} KB`;
      setFiles(prev => [...prev, { name: f.name, size: sizeFormatted, type: f.type || 'image/png' }]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!title.trim()) {
      setErrorMsg('Please enter a brief summary / title for your issue.');
      return;
    }
    if (!description.trim() || description.length < 20) {
      setErrorMsg('Please describe what happened in detail (at least 20 characters) so our triage team can help.');
      return;
    }
    if (!isAnonymous && (!name.trim() || !email.trim())) {
      setErrorMsg('Please enter your contact name and email or switch to Anonymous mode.');
      return;
    }
    if (!agreedNoCredentials) {
      setErrorMsg('You must confirm that you have not provided any passwords, OTPs, or private keys.');
      return;
    }
    if (!agreedScope) {
      setErrorMsg('You must acknowledge that CSO provides educational/initial triage and is not a law enforcement agency.');
      return;
    }

    setIsSubmitting(true);

    try {
      const ticketId = submitHelpTicket({
        studentName: isAnonymous ? 'Anonymous Student' : name,
        studentEmail: isAnonymous ? 'help-protected@temporary.cso' : email,
        studentPhone: phone || undefined,
        isAnonymous,
        category,
        title,
        description,
        platformInvolved,
        incidentDate,
        severity,
        evidenceFiles: files,
      });

      router.push(`/help-center/track?id=${ticketId}&new=true`);
    } catch {
      setErrorMsg('An error occurred submitting the ticket. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Back Link */}
      <Link 
        href="/help-center" 
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Cyber Help Center</span>
      </Link>

      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
          <LifeBuoy className="w-3.5 h-3.5" />
          <span>CONFIDENTIAL HELP REQUEST</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          Submit Cyber Incident for Triage
        </h1>
        <p className="text-sm text-slate-300">
          Fill in the details below. You will receive a unique ticket ID to track updates and converse securely with our response team.
        </p>
      </div>

      {/* Security Credential Warning */}
      <CredentialWarningCallout />

      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-200 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Form Card */}
      <form onSubmit={handleSubmit} className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6">
        {/* Identity & Confidentiality Mode */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>Identity & Privacy Preference</span>
            </h4>
            <p className="text-xs text-slate-400">
              You can submit confidentially with your name, or toggle Anonymous mode if preferred.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsAnonymous(!isAnonymous)}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition border ${
              isAnonymous 
                ? 'bg-purple-950 text-purple-300 border-purple-500/50' 
                : 'bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            {isAnonymous ? '✓ ANONYMOUS MODE ACTIVE' : 'Standard Confidential'}
          </button>
        </div>

        {/* Contact fields if not anonymous */}
        {!isAnonymous && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Your Full Name / Alias *</label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Tanvir Ahmed"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Email Address (for ticket updates) *</label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="e.g. student@du.ac.bd"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Phone (Optional)</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+8801700..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
              />
            </div>
          </div>
        )}

        {/* Category & Platform */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Incident Category *</label>
            <select
              value={category}
              onChange={e => setCategory(e.target.value as IncidentCategory)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-emerald-400 outline-none"
            >
              <option value="ACCOUNT_HACKING">Account Hijacking / Hacking</option>
              <option value="PHISHING">Phishing Link / Credential Harvest</option>
              <option value="ONLINE_SCAM">Online Scam / Fraud / Extortion</option>
              <option value="FAKE_ACCOUNT">Fake Account / Defamatory Profile</option>
              <option value="CYBERBULLYING">Cyberbullying & Harassment</option>
              <option value="THREATS">Severe Threats / Blackmail</option>
              <option value="PRIVACY_MISUSE">Privacy Leak / Unauthorized Data</option>
              <option value="MALWARE_DEVICE">Malware / Suspicious App / Device Issue</option>
              <option value="SUSPICIOUS_WEBSITE">Suspicious University / Govt Portal</option>
              <option value="OTHER">Other Cyber Problem</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Platform / Service Involved *</label>
            <input
              type="text"
              required
              value={platformInvolved}
              onChange={e => setPlatformInvolved(e.target.value)}
              placeholder="e.g. Facebook, Gmail, Telegram, bKash, Canvas"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
            />
          </div>
        </div>

        {/* Date & Severity */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Approximate Incident Date *</label>
            <input
              type="date"
              required
              value={incidentDate}
              onChange={e => setIncidentDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-emerald-400 outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Estimated Severity Level *</label>
            <select
              value={severity}
              onChange={e => setSeverity(e.target.value as TicketPriority)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-emerald-400 outline-none"
            >
              <option value="LOW">LOW — General advice / educational inquiry</option>
              <option value="MEDIUM">MEDIUM — Fake account / minor suspicious activity</option>
              <option value="HIGH">HIGH — Stolen active account / financial scam</option>
              <option value="CRITICAL">CRITICAL — Active blackmail / extortion / severe harassment</option>
            </select>
          </div>
        </div>

        {/* Title */}
        <div className="space-y-1">
          <label className="text-xs font-medium text-slate-300">Incident Summary / Headline *</label>
          <input
            type="text"
            required
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="e.g. University email hijacked after clicking scholarship link"
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
          />
        </div>

        {/* Description */}
        <div className="space-y-1">
          <label className="text-xs font-medium text-slate-300">Detailed Description of Incident *</label>
          <textarea
            required
            rows={5}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Describe what happened, any suspicious messages received, URLs visited, and actions you have already attempted. (Remember: DO NOT include any passwords or OTPs!)..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
          />
        </div>

        {/* Evidence Upload Section */}
        <div className="space-y-2">
          <label className="text-xs font-medium text-slate-300">
            Attach Evidence (Screenshots, Headers, Emails)
          </label>
          <div className="p-4 border-2 border-dashed border-slate-700 hover:border-emerald-500/50 rounded-2xl bg-slate-950/60 text-center space-y-2">
            <Upload className="w-6 h-6 text-slate-400 mx-auto" />
            <div className="text-xs text-slate-300">
              <label className="text-emerald-400 hover:underline cursor-pointer font-semibold">
                Click to attach files
                <input 
                  type="file" 
                  className="hidden" 
                  onChange={handleSimulatedFileUpload}
                  accept="image/png,image/jpeg,application/pdf,.eml,.txt"
                />
              </label>
              <span className="text-slate-400"> or drag and drop</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              Accepted formats: PNG, JPG, PDF, EML (Max 10MB each). Files stored privately.
            </p>
          </div>

          {files.length > 0 && (
            <div className="space-y-1 pt-2">
              <span className="text-[11px] font-mono text-slate-400">Attached Evidence ({files.length}):</span>
              {files.map((file, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2 text-slate-200">
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{file.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">({file.size})</span>
                  </div>
                  <button 
                    type="button" 
                    onClick={() => removeFile(idx)}
                    className="text-red-400 hover:text-red-300 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Mandatory Affirmation Checkboxes */}
        <div className="space-y-3 pt-3 border-t border-slate-800">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              required
              checked={agreedNoCredentials}
              onChange={e => setAgreedNoCredentials(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded bg-slate-950 border-slate-700 text-emerald-500 focus:ring-0"
            />
            <span className="text-xs text-slate-300 leading-relaxed">
              <strong className="text-red-300">Mandatory Security Confirmation:</strong> I explicitly confirm that I <strong>HAVE NOT</strong> included any passwords, OTP codes, authentication keys, or financial PINs in this request or any attached screenshot.
            </span>
          </label>

          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              required
              checked={agreedScope}
              onChange={e => setAgreedScope(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded bg-slate-950 border-slate-700 text-emerald-500 focus:ring-0"
            />
            <span className="text-xs text-slate-300 leading-relaxed">
              I understand that the CyberSafe Student Organization (CSO) is a student-led educational and triage body, not a law-enforcement agency. Severe crimes will be guided toward police authorities.
            </span>
          </label>
        </div>

        {/* Submit button */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="text-[11px] text-slate-400 font-mono">
            ✓ Encrypted submission • Logged in audit trail
          </span>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition disabled:opacity-50"
          >
            {isSubmitting ? 'Securing & Generating Ticket...' : 'Submit Confidential Help Request →'}
          </button>
        </div>
      </form>
    </div>
  );
}

export default function SubmitHelpPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading Help Form...</div>}>
      <HelpRequestForm />
    </Suspense>
  );
}
