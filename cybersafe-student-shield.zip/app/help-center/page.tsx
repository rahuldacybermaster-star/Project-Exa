'use client';

import React from 'react';
import Link from 'next/link';
import { 
  LifeBuoy, 
  ShieldAlert, 
  Lock, 
  Search, 
  MessageSquare, 
  FileText, 
  AlertTriangle, 
  Clock, 
  ArrowRight, 
  PhoneCall, 
  CheckCircle,
  HelpCircle,
  Zap,
  GlobeLock
} from 'lucide-react';
import { CredentialWarningCallout } from '@/components/DisclaimerBanner';

export default function HelpCenterPage() {
  const commonIssues = [
    {
      title: 'Compromised Social Media Account',
      category: 'Account Hacking',
      description: 'Attacker changed recovery email, enabled unauthorized 2FA, or logged out all active sessions.',
      actionUrl: '/help-center/submit?category=ACCOUNT_HACKING',
      severity: 'HIGH',
    },
    {
      title: 'Targeted Phishing Link / Fake Portal',
      category: 'Phishing',
      description: 'Entered login credentials or OTP on a spoofed university stipend, scholarship, or giveaway link.',
      actionUrl: '/help-center/submit?category=PHISHING',
      severity: 'HIGH',
    },
    {
      title: 'Fake Account & Impersonation Harassment',
      category: 'Cyberbullying & Fake Accounts',
      description: 'Someone created an account with your real name and photos to defame or harass classmates.',
      actionUrl: '/help-center/submit?category=FAKE_ACCOUNT',
      severity: 'MEDIUM',
    },
    {
      title: 'Online Scam / MFS Advance Payment Fraud',
      category: 'Financial Fraud',
      description: 'Defrauded via Telegram task scam, fake online marketplace, or fraudulent bKash/Nagad transfer.',
      actionUrl: '/help-center/submit?category=ONLINE_SCAM',
      severity: 'HIGH',
    },
    {
      title: 'Blackmail, Extortion & Threatening Messages',
      category: 'Online Threats',
      description: 'Receiving extortion threats involving private images, sensitive data, or physical harm.',
      actionUrl: '/help-center/submit?category=THREATS',
      severity: 'CRITICAL',
    },
    {
      title: 'Suspicious Device Malware / Keylogger',
      category: 'Device Security',
      description: 'Downloaded infected cracked software or suspicious APK resulting in unknown account activity.',
      actionUrl: '/help-center/submit?category=MALWARE_DEVICE',
      severity: 'MEDIUM',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
          <LifeBuoy className="w-3.5 h-3.5" />
          <span>CONFIDENTIAL STUDENT CYBER TRIAGE DESK</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white">
          Cyber Help & Incident Triage Center
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          Encountered a cyber security emergency or suspicious online activity? Submit a confidential request to receive step-by-step guidance from our trained student triage team.
        </p>
      </div>

      {/* Mandatory Credential Security Notice */}
      <CredentialWarningCallout />

      {/* Quick Action Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-gradient-to-b from-emerald-950/40 to-slate-900 border border-emerald-500/40 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Submit Help Request</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Open a secure ticket with evidence. Receive an official tracking ID (e.g. CSO-HLP-82741).
            </p>
          </div>
          <Link
            href="/help-center/submit"
            className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs text-center transition flex items-center justify-center gap-1.5"
          >
            <span>Open Help Ticket</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-900/60 border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Track Existing Ticket</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Check the live status of your ticket, view assigned agent messages, and review triage memos.
            </p>
          </div>
          <Link
            href="/help-center/track"
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs text-center border border-slate-700 transition flex items-center justify-center gap-1.5"
          >
            <span>Enter Ticket ID</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-900/60 border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Live Support Chat</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Need quick guidance? Start a real-time conversation with an active student responder.
            </p>
          </div>
          <Link
            href="/chat"
            className="w-full py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-blue-200 border border-blue-500/40 font-semibold text-xs text-center transition flex items-center justify-center gap-1.5"
          >
            <span>Launch Live Chat</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* Common Incident Categories */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">Select Incident Category for Guided Triage</h2>
            <p className="text-xs text-slate-400">Click any common cyber problem below to auto-fill your help ticket</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {commonIssues.map((issue, idx) => (
            <div 
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">{issue.category}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    issue.severity === 'CRITICAL' ? 'bg-red-950 text-red-300 border border-red-500/40' :
                    issue.severity === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-500/40' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {issue.severity}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white">{issue.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{issue.description}</p>
              </div>

              <Link
                href={issue.actionUrl}
                className="inline-flex items-center gap-1 text-xs text-emerald-400 font-semibold hover:underline"
              >
                Request Assistance for this Issue →
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Immediate Self-Help Rules */}
      <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <span>Immediate Golden Rules While Waiting for Triage</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="text-emerald-400 font-bold font-mono">Rule 1: Preserve Evidence</div>
            <p className="text-slate-400 leading-relaxed">
              Take full-screen screenshots showing sender headers, full URLs, timestamps, and usernames before accounts are deleted.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="text-emerald-400 font-bold font-mono">Rule 2: Never Pay Scammers</div>
            <p className="text-slate-400 leading-relaxed">
              Never send ransom or &ldquo;unblock fees&rdquo;. Attackers will continually demand more money without returning your data.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="text-emerald-400 font-bold font-mono">Rule 3: Revoke Device Access</div>
            <p className="text-slate-400 leading-relaxed">
              From another clean device, navigate to your account security settings and click &ldquo;Log out of all other sessions&rdquo;.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="text-emerald-400 font-bold font-mono">Rule 4: Alert Friends</div>
            <p className="text-slate-400 leading-relaxed">
              If your WhatsApp or Facebook is hijacked, immediately inform family/friends so they ignore money requests from your stolen profile.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
