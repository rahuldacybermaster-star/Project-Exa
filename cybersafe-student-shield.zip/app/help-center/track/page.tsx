'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  Search, 
  LifeBuoy, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Send, 
  Lock, 
  FileText, 
  User, 
  ArrowLeft,
  ChevronRight,
  Shield,
  MessageSquare
} from 'lucide-react';
import { useApp } from '@/lib/app-context';
import { HelpTicket, TicketStatus } from '@/lib/types';
import { CredentialWarningCallout } from '@/components/DisclaimerBanner';

function TicketTrackerContent() {
  const searchParams = useSearchParams();
  const initialTicketId = searchParams.get('id') || '';
  const isNew = searchParams.get('new') === 'true';

  const { tickets, addTicketMessage, updateTicketStatus, currentUser } = useApp();
  const [searchId, setSearchId] = useState(() => {
    if (initialTicketId) return initialTicketId;
    return tickets[0]?.id || '';
  });
  const [activeTicketId, setActiveTicketId] = useState<string>(() => {
    if (initialTicketId) return initialTicketId;
    return tickets[0]?.id || '';
  });
  const [replyMessage, setReplyMessage] = useState('');
  const [isInternalNote, setIsInternalNote] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState(isNew);

  const selectedTicket = tickets.find(t => t.id.toLowerCase() === (activeTicketId || searchId).trim().toLowerCase()) || null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    setActiveTicketId(searchId.trim());
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage.trim() || !selectedTicket) return;

    addTicketMessage(selectedTicket.id, replyMessage.trim(), isInternalNote);
    setReplyMessage('');
  };

  const isStaff = currentUser?.role !== 'STUDENT' && currentUser?.role !== 'GUEST';

  const statusColors: Record<TicketStatus, string> = {
    NEW: 'bg-blue-950 text-blue-300 border-blue-500/40',
    UNDER_REVIEW: 'bg-purple-950 text-purple-300 border-purple-500/40',
    NEED_INFORMATION: 'bg-amber-950 text-amber-300 border-amber-500/40',
    IN_PROGRESS: 'bg-emerald-950 text-emerald-300 border-emerald-500/40',
    WAITING_FOR_USER: 'bg-orange-950 text-orange-300 border-orange-500/40',
    RESOLVED: 'bg-teal-950 text-teal-300 border-teal-500/40',
    CLOSED: 'bg-slate-800 text-slate-300 border-slate-700',
    REJECTED: 'bg-red-950 text-red-300 border-red-500/40',
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Breadcrumb / Back */}
      <div className="flex items-center justify-between">
        <Link 
          href="/help-center" 
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-emerald-400 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Cyber Help Center</span>
        </Link>
        <Link
          href="/help-center/submit"
          className="text-xs font-semibold text-emerald-400 hover:underline"
        >
          + Submit Another Request
        </Link>
      </div>

      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
          <Clock className="w-3.5 h-3.5" />
          <span>INCIDENT TICKET TRACKER & COMMUNICATIONS</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          Track Help Ticket Status
        </h1>
        <p className="text-sm text-slate-300">
          Enter your unique ticket reference code (e.g., <code className="font-mono text-emerald-300">CSO-HLP-82741</code>) to view real-time triage updates.
        </p>
      </div>

      {feedbackSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>
              <strong>Ticket Created Successfully!</strong> Your ticket ID has been registered. Bookmark this page to track updates.
            </span>
          </div>
          <button 
            onClick={() => setFeedbackSuccess(false)}
            className="text-slate-400 hover:text-white text-xs underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Search Input Bar */}
      <form onSubmit={handleSearch} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchId}
            onChange={e => setSearchId(e.target.value)}
            placeholder="Enter Ticket ID (e.g. CSO-HLP-82741, CSO-HLP-49210)..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none font-mono"
          />
        </div>
        <button
          type="submit"
          className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm transition"
        >
          Track Ticket
        </button>
      </form>

      {/* Ticket Container */}
      {!selectedTicket ? (
        <div className="p-12 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-4">
          <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
          <h3 className="text-lg font-bold text-white">Ticket Not Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            No incident ticket found matching &ldquo;{searchId}&rdquo;. Please verify your ID or submit a new help request.
          </p>
          <div className="pt-2">
            <Link
              href="/help-center/submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs inline-block"
            >
              Open New Help Ticket
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Column: Ticket Info & Messages */}
          <div className="lg:col-span-2 space-y-6">
            {/* Ticket Header Card */}
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg font-extrabold text-white font-mono">
                    {selectedTicket.id}
                  </span>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold border ${statusColors[selectedTicket.status]}`}>
                    {selectedTicket.status.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="text-xs font-mono text-slate-400">
                  Priority: <span className="text-red-400 font-bold">{selectedTicket.priority}</span>
                </div>
              </div>

              <div>
                <h2 className="text-lg sm:text-xl font-bold text-white">{selectedTicket.title}</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Category: <span className="text-slate-200">{selectedTicket.category.replace(/_/g, ' ')}</span> • Platform: <span className="text-slate-200">{selectedTicket.platformInvolved}</span>
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                <div className="font-semibold text-slate-200 mb-1">Initial Incident Description:</div>
                <p className="whitespace-pre-wrap">{selectedTicket.description}</p>
              </div>

              {selectedTicket.evidenceFiles && selectedTicket.evidenceFiles.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[11px] font-mono text-slate-400">Preserved Evidence Files:</span>
                  <div className="flex flex-wrap gap-2">
                    {selectedTicket.evidenceFiles.map((file, idx) => (
                      <div key={idx} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 font-mono">
                        <FileText className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{file.name}</span>
                        <span className="text-[10px] text-slate-500">({file.size})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Conversation / Messages Stream */}
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
              <h3 className="text-sm font-bold uppercase tracking-widest text-slate-200 font-mono flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Triage Communication Stream</span>
              </h3>

              <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                {selectedTicket.messages
                  .filter(m => !m.isInternalNote || isStaff)
                  .map(msg => {
                    const isStaffSender = msg.senderRole !== 'Student' && msg.senderRole !== 'Guest';
                    return (
                      <div 
                        key={msg.id}
                        className={`p-4 rounded-2xl border text-xs space-y-2 ${
                          msg.isInternalNote 
                            ? 'bg-amber-950/40 border-amber-500/40 text-amber-200' 
                            : isStaffSender 
                            ? 'bg-emerald-950/30 border-emerald-500/30 text-slate-200' 
                            : 'bg-slate-950/70 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11px]">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">{msg.senderName}</span>
                            <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                              {msg.senderRole}
                            </span>
                            {msg.isInternalNote && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-900 text-amber-300 font-mono text-[10px] font-bold">
                                INTERNAL NOTE (STAFF ONLY)
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {new Date(msg.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <p className="whitespace-pre-wrap leading-relaxed">{msg.message}</p>
                      </div>
                    );
                  })}
              </div>

              {/* Message Reply Form */}
              <form onSubmit={handleSendMessage} className="space-y-3 pt-3 border-t border-slate-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Post update or question to responder:</span>
                  {isStaff && (
                    <label className="flex items-center gap-2 text-amber-300 cursor-pointer text-[11px] font-mono">
                      <input 
                        type="checkbox" 
                        checked={isInternalNote} 
                        onChange={e => setIsInternalNote(e.target.checked)} 
                        className="rounded bg-slate-950 border-slate-700 text-amber-500"
                      />
                      <span>Post as Internal Staff Note</span>
                    </label>
                  )}
                </div>

                <div className="flex gap-2">
                  <textarea
                    rows={2}
                    required
                    value={replyMessage}
                    onChange={e => setReplyMessage(e.target.value)}
                    placeholder="Type your message here... (Remember: DO NOT share any passwords or OTP codes!)"
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 outline-none"
                  />
                  <button
                    type="submit"
                    className="px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right Sidebar: Timeline & Status Controls */}
          <div className="space-y-6">
            {/* Responder & Status Summary */}
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-semibold">
                Triage Overview
              </h4>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block">Assigned Support Agent:</span>
                  <span className="font-semibold text-slate-200">
                    {selectedTicket.assignedAgentName || 'Queued in Triage Pool'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Requester:</span>
                  <span className="font-semibold text-slate-200">
                    {selectedTicket.studentName} {selectedTicket.isAnonymous ? '(Anonymous)' : ''}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Created At:</span>
                  <span className="font-mono text-slate-300">
                    {new Date(selectedTicket.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Last Active:</span>
                  <span className="font-mono text-slate-300">
                    {new Date(selectedTicket.updatedAt).toLocaleTimeString()}
                  </span>
                </div>
              </div>

              {/* Staff Status Changer */}
              {isStaff && (
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">
                    STAFF ACTION: UPDATE STATUS
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                    <button
                      onClick={() => updateTicketStatus(selectedTicket.id, 'IN_PROGRESS', 'Agent actively investigating IoCs.')}
                      className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      In Progress
                    </button>
                    <button
                      onClick={() => updateTicketStatus(selectedTicket.id, 'WAITING_FOR_USER', 'Requested clarification from student.')}
                      className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      Waiting User
                    </button>
                    <button
                      onClick={() => updateTicketStatus(selectedTicket.id, 'RESOLVED', 'Resolution guide delivered.')}
                      className="p-1.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold"
                    >
                      Mark Resolved
                    </button>
                    <button
                      onClick={() => updateTicketStatus(selectedTicket.id, 'CLOSED', 'Ticket finalized.')}
                      className="p-1.5 rounded bg-slate-800 text-slate-400"
                    >
                      Close Ticket
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Audit Timeline */}
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-semibold">
                Event Timeline
              </h4>
              <div className="space-y-4 text-xs">
                {selectedTicket.timeline.map((item, idx) => (
                  <div key={item.id || idx} className="flex items-start gap-2.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 shrink-0"></div>
                    <div className="space-y-0.5">
                      <div className="font-semibold text-slate-200">{item.action}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        By {item.performedBy} • {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      {item.notes && <div className="text-[11px] text-slate-400">{item.notes}</div>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function TrackTicketPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading Ticket Tracker...</div>}>
      <TicketTrackerContent />
    </Suspense>
  );
}
